<?
define("BX_SKIP_USER_LIMIT_CHECK", true);
include($_SERVER["DOCUMENT_ROOT"]."/bitrix/components/bitrix/im.messenger/show.file.php");
?>