<?
require($_SERVER["DOCUMENT_ROOT"]."/limit/index.php");