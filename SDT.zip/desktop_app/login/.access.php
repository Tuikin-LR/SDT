<?
$PERM["index.php"]["2"]="R";
?>