<?
define("BX_SKIP_USER_LIMIT_CHECK", true);
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/admin/user_options.php");
?>