<?
define("BX_SKIP_USER_LIMIT_CHECK", true);
$_POST['desktop_action'] = 'Y';
include($_SERVER["DOCUMENT_ROOT"]."/bitrix/components/bitrix/im.messenger/im.ajax.php");
?>