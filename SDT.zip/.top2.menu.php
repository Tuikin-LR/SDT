<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$aMenuLinks = Array(
	Array(
		"Акции", 
		"#", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Брэнды", 
		"#", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Доставка и оплата", 
		"#", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Сервис", 
		"/service/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"О компании", 
		"/about/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Контакты", 
		"#", 
		Array(), 
		Array(), 
		"" 
	)
);
?>