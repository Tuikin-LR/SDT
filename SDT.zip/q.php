<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $item
 * @var array $actualItem
 * @var array $minOffer
 * @var array $itemIds
 * @var array $price
 * @var array $measureRatio
 * @var bool $haveOffers
 * @var bool $showSubscribe
 * @var array $morePhoto
 * @var bool $showSlider
 * @var bool $itemHasDetailUrl
 * @var string $imgTitle
 * @var string $productTitle
 * @var string $buttonSizeClass
 * @var CatalogSectionComponent $component
 */

if ($item['LABEL'])
{
    ?>
    <?
    if (!empty($item['LABEL_ARRAY_VALUE']))
    {
        foreach ($item['LABEL_ARRAY_VALUE'] as $code => $value)
        {
            if ($value=='Лидер продаж'){?>
                <span<?=(!isset($item['LABEL_PROP_MOBILE'][$code]) ? ' class="index-product-tag is-only' : '')?> title="<?=$value?>"><?=$value?>
						    </span>
            <?}elseif ($value=='Новинка'){?>
                <span<?=(!isset($item['LABEL_PROP_MOBILE'][$code]) ? ' class="index-product-tag is-new' : '')?> title="<?=$value?>"><?=$value?>
						    </span>
            <?}elseif ($value=='Спецпредложение'){?>
                <span<?=(!isset($item['LABEL_PROP_MOBILE'][$code]) ? ' class="index-product-tag is-bestaller' : '')?> title="<?=$value?>"><?=$value?>
						    </span>
            <?}
        }
    }
    ?>
    <?
}?>
    <div class="index-product-img-slider">
        <?foreach ($morePhoto as $key => $photo){?>
            <a href="#" class="index-product_img">
                <img src="<?=$photo['SRC']?>" alt="">
            </a>
        <?}?>
    </div>

<?
if ($item['SECOND_PICT'])
{
    $bgImage = !empty($item['PREVIEW_PICTURE_SECOND']) ? $item['PREVIEW_PICTURE_SECOND']['SRC'] : $item['PREVIEW_PICTURE']['SRC'];
    ?>
    <span class="product-item-image-alternative" id="<?=$itemIds['SECOND_PICT']?>"
          style="background-image: url('<?=$bgImage?>'); <?=($showSlider ? 'display: none;' : '')?>">
			</span>
    <?
}

if ($arParams['SHOW_DISCOUNT_PERCENT'] === 'Y')
{
    ?>
    <div class="product-item-label-ring <?=$discountPositionClass?>" id="<?=$itemIds['DSC_PERC']?>"
        <?=($price['PERCENT'] > 0 ? '' : 'style="display: none;"')?>>
        <span><?=-$price['PERCENT']?>%</span>
    </div>
    <?
}


?>
    <div class="index-product_buttons">
        <a href="#" class="index-product_compare" data-catalog="{'action':'compare','id':'38'}">
            <svg>
                <use href="assets/img/svg-icons.svg#product-compare"></use>
            </svg>
        </a>
        <a href="#" class="index-product_favorite" data-catalog="{'action':'favorite','id':'38'}">
            <svg class="is-not-active">
                <use href="assets/img/svg-icons.svg#product-favorite"></use>
            </svg>
            <svg class="is-active">
                <use href="assets/img/svg-icons.svg#product-favorite-active"></use>
            </svg>
        </a>
    </div><?
?>

<?
if ($arParams['SLIDER_PROGRESS'] === 'Y')
{
    ?>
    <div class="product-item-image-slider-progress-bar-container">
        <div class="product-item-image-slider-progress-bar" id="<?=$itemIds['PICT_SLIDER']?>_progress_bar" style="width: 0;"></div>
    </div>
    <?
}
?>
<? if ($itemHasDetailUrl): ?>
    </a>
<? else: ?>
    </span>
<? endif; ?>
    <div class="index-product_name">
        <? if ($itemHasDetailUrl): ?>
            <!--		<a href="--><?//=$item['DETAIL_PAGE_URL']?><!--" title="--><?//=$productTitle?><!--">-->
        <? endif; ?>
        <?=$productTitle?>
        <? if ($itemHasDetailUrl): ?>
            </a>
        <? endif; ?>
    </div>
<?
if (!empty($arParams['PRODUCT_BLOCKS_ORDER']))
{
    foreach ($arParams['PRODUCT_BLOCKS_ORDER'] as $blockName)
    {
        switch ($blockName)
        {
            case 'price': ?>
                <div class="index-product_price" data-entity="price-block">
                    <?
                    if ($arParams['SHOW_OLD_PRICE'] === 'Y')
                    {
                        ?>
                        <div class="is-old-price" id="<?=$itemIds['PRICE_OLD']?>"
                            <?=($price['RATIO_PRICE'] >= $price['RATIO_BASE_PRICE'] ? 'style="display: none;"' : '')?>>
                            <?=$price['PRINT_RATIO_BASE_PRICE']?>
                        </div>&nbsp;
                        <?
                    }
                    ?>
                    <div class="is-new-price" id="<?=$itemIds['PRICE']?>">
                        <?
                        if (!empty($price))
                        {
                            echo number_format($price['PRICE'],0, '', ' ').' руб.';
                        }
                        ?>
                    </div>
                </div>
                <?
                break;

            case 'quantityLimit':
                if ($arParams['SHOW_MAX_QUANTITY'] !== 'N')
                {
                    if ($haveOffers)
                    {
                        if ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y')
                        {
                            ?>
                            <div class="product-item-info-container product-item-hidden" id="<?=$itemIds['QUANTITY_LIMIT']?>"
                                 style="display: none;" data-entity="quantity-limit-block">
                                <div class="product-item-info-container-title">
                                    <?=$arParams['MESS_SHOW_MAX_QUANTITY']?>:
                                    <span class="product-item-quantity" data-entity="quantity-limit-value"></span>
                                </div>
                            </div>
                            <?
                        }
                    }
                    else
                    {
                        if (
                            $measureRatio
                            && (float)$actualItem['CATALOG_QUANTITY'] > 0
                            && $actualItem['CATALOG_QUANTITY_TRACE'] === 'Y'
                            && $actualItem['CATALOG_CAN_BUY_ZERO'] === 'N'
                        )
                        {
                            ?>
                            <div class="product-item-info-container product-item-hidden" id="<?=$itemIds['QUANTITY_LIMIT']?>">
                                <div class="product-item-info-container-title">
                                    <?=$arParams['MESS_SHOW_MAX_QUANTITY']?>:
                                    <span class="product-item-quantity">
											<?
                                            if ($arParams['SHOW_MAX_QUANTITY'] === 'M')
                                            {
                                                if ((float)$actualItem['CATALOG_QUANTITY'] / $measureRatio >= $arParams['RELATIVE_QUANTITY_FACTOR'])
                                                {
                                                    echo $arParams['MESS_RELATIVE_QUANTITY_MANY'];
                                                }
                                                else
                                                {
                                                    echo $arParams['MESS_RELATIVE_QUANTITY_FEW'];
                                                }
                                            }
                                            else
                                            {
                                                echo $actualItem['CATALOG_QUANTITY'].' '.$actualItem['ITEM_MEASURE']['TITLE'];
                                            }
                                            ?>
										</span>
                                </div>
                            </div>
                            <?
                        }
                    }
                }

                break;

            case 'quantity':
                if (!$haveOffers)
                {
                    if ($actualItem['CAN_BUY'] && $arParams['USE_PRODUCT_QUANTITY'])
                    {
                        ?>
                        <div class="product-item-info-container product-item-hidden" data-entity="quantity-block">
                            <div class="product-item-amount">
                                <div class="product-item-amount-field-container">
                                    <span class="product-item-amount-field-btn-minus no-select" id="<?=$itemIds['QUANTITY_DOWN']?>"></span>
                                    <input class="product-item-amount-field" id="<?=$itemIds['QUANTITY']?>" type="number"
                                           name="<?=$arParams['PRODUCT_QUANTITY_VARIABLE']?>"
                                           value="<?=$measureRatio?>">
                                    <span class="product-item-amount-field-btn-plus no-select" id="<?=$itemIds['QUANTITY_UP']?>"></span>
                                    <span class="product-item-amount-description-container">
											<span id="<?=$itemIds['QUANTITY_MEASURE']?>">
												<?=$actualItem['ITEM_MEASURE']['TITLE']?>
											</span>
											<span id="<?=$itemIds['PRICE_TOTAL']?>"></span>
										</span>
                                </div>
                            </div>
                        </div>
                        <?
                    }
                }
                elseif ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y')
                {
                    if ($arParams['USE_PRODUCT_QUANTITY'])
                    {
                        ?>
                        <div class="product-item-info-container product-item-hidden" data-entity="quantity-block">
                            <div class="product-item-amount">
                                <div class="product-item-amount-field-container">
                                    <span class="product-item-amount-field-btn-minus no-select" id="<?=$itemIds['QUANTITY_DOWN']?>"></span>
                                    <input class="product-item-amount-field" id="<?=$itemIds['QUANTITY']?>" type="number"
                                           name="<?=$arParams['PRODUCT_QUANTITY_VARIABLE']?>"
                                           value="<?=$measureRatio?>">
                                    <span class="product-item-amount-field-btn-plus no-select" id="<?=$itemIds['QUANTITY_UP']?>"></span>
                                    <span class="product-item-amount-description-container">
											<span id="<?=$itemIds['QUANTITY_MEASURE']?>"><?=$actualItem['ITEM_MEASURE']['TITLE']?></span>
											<span id="<?=$itemIds['PRICE_TOTAL']?>"></span>
										</span>
                                </div>
                            </div>
                        </div>
                        <?
                    }
                }

                break;

            case 'buttons':
                ?>
                <div class="product-item-info-container product-item-hidden" data-entity="buttons-block">
                    <?
                    if (!$haveOffers)
                    {
                        if ($actualItem['CAN_BUY'])
                        {
                            ?>
                            <div class="product-item-button-container" id="<?=$itemIds['BASKET_ACTIONS']?>">
                                <a class="btn btn-default <?=$buttonSizeClass?>" id="<?=$itemIds['BUY_LINK']?>"
                                   href="javascript:void(0)" rel="nofollow">
                                    <?=($arParams['ADD_TO_BASKET_ACTION'] === 'BUY' ? $arParams['MESS_BTN_BUY'] : $arParams['MESS_BTN_ADD_TO_BASKET'])?>
                                </a>
                            </div>
                            <?
                        }
                        else
                        {
                            ?>
                            <div class="product-item-button-container">
                                <?
                                if ($showSubscribe)
                                {
                                    $APPLICATION->IncludeComponent(
                                        'bitrix:catalog.product.subscribe',
                                        '',
                                        array(
                                            'PRODUCT_ID' => $actualItem['ID'],
                                            'BUTTON_ID' => $itemIds['SUBSCRIBE_LINK'],
                                            'BUTTON_CLASS' => 'btn btn-default '.$buttonSizeClass,
                                            'DEFAULT_DISPLAY' => true,
                                            'MESS_BTN_SUBSCRIBE' => $arParams['~MESS_BTN_SUBSCRIBE'],
                                        ),
                                        $component,
                                        array('HIDE_ICONS' => 'Y')
                                    );
                                }
                                ?>
                                <a class="btn btn-link <?=$buttonSizeClass?>"
                                   id="<?=$itemIds['NOT_AVAILABLE_MESS']?>" href="javascript:void(0)" rel="nofollow">
                                    <?=$arParams['MESS_NOT_AVAILABLE']?>
                                </a>
                            </div>
                            <?
                        }
                    }
                    else
                    {
                        if ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y')
                        {
                            ?>
                            <div class="product-item-button-container">
                                <?
                                if ($showSubscribe)
                                {
                                    $APPLICATION->IncludeComponent(
                                        'bitrix:catalog.product.subscribe',
                                        '',
                                        array(
                                            'PRODUCT_ID' => $item['ID'],
                                            'BUTTON_ID' => $itemIds['SUBSCRIBE_LINK'],
                                            'BUTTON_CLASS' => 'btn btn-default '.$buttonSizeClass,
                                            'DEFAULT_DISPLAY' => !$actualItem['CAN_BUY'],
                                            'MESS_BTN_SUBSCRIBE' => $arParams['~MESS_BTN_SUBSCRIBE'],
                                        ),
                                        $component,
                                        array('HIDE_ICONS' => 'Y')
                                    );
                                }
                                ?>
                                <a class="btn btn-link <?=$buttonSizeClass?>"
                                   id="<?=$itemIds['NOT_AVAILABLE_MESS']?>" href="javascript:void(0)" rel="nofollow"
                                    <?=($actualItem['CAN_BUY'] ? 'style="display: none;"' : '')?>>
                                    <?=$arParams['MESS_NOT_AVAILABLE']?>
                                </a>
                                <div id="<?=$itemIds['BASKET_ACTIONS']?>" <?=($actualItem['CAN_BUY'] ? '' : 'style="display: none;"')?>>
                                    <a class="btn btn-default <?=$buttonSizeClass?>" id="<?=$itemIds['BUY_LINK']?>"
                                       href="javascript:void(0)" rel="nofollow">
                                        <?=($arParams['ADD_TO_BASKET_ACTION'] === 'BUY' ? $arParams['MESS_BTN_BUY'] : $arParams['MESS_BTN_ADD_TO_BASKET'])?>
                                    </a>
                                </div>
                            </div>
                            <?
                        }
                        else
                        {
                            ?>
                            <a href="#" class="index-product_basket button">В корзину</a>
                            <?
                        }
                    }
                    ?>
                </div>
                <?
                break;

            case 'sku':
                if ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y' && $haveOffers && !empty($item['OFFERS_PROP']))
                {
                    ?>
                    <div id="<?=$itemIds['PROP_DIV']?>">
                        <?
                        foreach ($arParams['SKU_PROPS'] as $skuProperty)
                        {
                            $propertyId = $skuProperty['ID'];
                            $skuProperty['NAME'] = htmlspecialcharsbx($skuProperty['NAME']);
                            if (!isset($item['SKU_TREE_VALUES'][$propertyId]))
                                continue;
                            ?>
                            <div class="product-item-info-container product-item-hidden" data-entity="sku-block">
                                <div class="product-item-scu-container" data-entity="sku-line-block">
                                    <?=$skuProperty['NAME']?>
                                    <div class="product-item-scu-block">
                                        <div class="product-item-scu-list">
                                            <ul class="product-item-scu-item-list">
                                                <?
                                                foreach ($skuProperty['VALUES'] as $value)
                                                {
                                                    if (!isset($item['SKU_TREE_VALUES'][$propertyId][$value['ID']]))
                                                        continue;

                                                    $value['NAME'] = htmlspecialcharsbx($value['NAME']);

                                                    if ($skuProperty['SHOW_MODE'] === 'PICT')
                                                    {
                                                        ?>
                                                        <li class="product-item-scu-item-color-container" title="<?=$value['NAME']?>"
                                                            data-treevalue="<?=$propertyId?>_<?=$value['ID']?>" data-onevalue="<?=$value['ID']?>">
                                                            <div class="product-item-scu-item-color-block">
                                                                <div class="product-item-scu-item-color" title="<?=$value['NAME']?>"
                                                                     style="background-image: url('<?=$value['PICT']['SRC']?>');">
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <?
                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <li class="product-item-scu-item-text-container" title="<?=$value['NAME']?>"
                                                            data-treevalue="<?=$propertyId?>_<?=$value['ID']?>" data-onevalue="<?=$value['ID']?>">
                                                            <div class="product-item-scu-item-text-block">
                                                                <div class="product-item-scu-item-text"><?=$value['NAME']?></div>
                                                            </div>
                                                        </li>
                                                        <?
                                                    }
                                                }
                                                ?>
                                            </ul>
                                            <div style="clear: both;"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?
                        }
                        ?>
                    </div>
                    <?
                    foreach ($arParams['SKU_PROPS'] as $skuProperty)
                    {
                        if (!isset($item['OFFERS_PROP'][$skuProperty['CODE']]))
                            continue;

                        $skuProps[] = array(
                            'ID' => $skuProperty['ID'],
                            'SHOW_MODE' => $skuProperty['SHOW_MODE'],
                            'VALUES' => $skuProperty['VALUES'],
                            'VALUES_COUNT' => $skuProperty['VALUES_COUNT']
                        );
                    }

                    unset($skuProperty, $value);

                    if ($item['OFFERS_PROPS_DISPLAY'])
                    {
                        foreach ($item['JS_OFFERS'] as $keyOffer => $jsOffer)
                        {
                            $strProps = '';

                            if (!empty($jsOffer['DISPLAY_PROPERTIES']))
                            {
                                foreach ($jsOffer['DISPLAY_PROPERTIES'] as $displayProperty)
                                {
                                    $strProps .= '<dt>'.$displayProperty['NAME'].'</dt><dd>'
                                        .(is_array($displayProperty['VALUE'])
                                            ? implode(' / ', $displayProperty['VALUE'])
                                            : $displayProperty['VALUE'])
                                        .'</dd>';
                                }
                            }

                            $item['JS_OFFERS'][$keyOffer]['DISPLAY_PROPERTIES'] = $strProps;
                        }
                        unset($jsOffer, $strProps);
                    }
                }

                break;
        }
    }
}

if (
    $arParams['DISPLAY_COMPARE']
    && (!$haveOffers || $arParams['PRODUCT_DISPLAY_MODE'] === 'Y')
)
{
    ?>
    <div class="product-item-compare-container">
        <div class="product-item-compare">
            <div class="checkbox">
                <label id="<?=$itemIds['COMPARE_LINK']?>">
                    <input type="checkbox" data-entity="compare-checkbox">
                    <span data-entity="compare-title"><?=$arParams['MESS_BTN_COMPARE']?></span>
                </label>
            </div>
        </div>
    </div>
    <?
}
?>






























$templateData = array(
	'TEMPLATE_THEME' => $this->GetFolder().'/themes/'.$arParams['TEMPLATE_THEME'].'/colors.css',
	'TEMPLATE_CLASS' => 'bx-'.$arParams['TEMPLATE_THEME']
);

if (isset($templateData['TEMPLATE_THEME']))
{
	$this->addExternalCss($templateData['TEMPLATE_THEME']);
}
$this->addExternalCss("/bitrix/css/main/bootstrap.css");
$this->addExternalCss("/bitrix/css/main/font-awesome.css");
?>
<div class="bx-filter <?=$templateData["TEMPLATE_CLASS"]?> <?if ($arParams["FILTER_VIEW_MODE"] == "HORIZONTAL") echo "bx-filter-horizontal"?>">
	<div class="bx-filter-section container-fluid">
		<div class="row"><div class="<?if ($arParams["FILTER_VIEW_MODE"] == "HORIZONTAL"):?>col-sm-6 col-md-4<?else:?>col-lg-12<?endif?> bx-filter-title"><?echo GetMessage("CT_BCSF_FILTER_TITLE")?></div></div>
		<form name="<?echo $arResult["FILTER_NAME"]."_form"?>" action="<?echo $arResult["FORM_ACTION"]?>" method="get" class="smartfilter">
			<?foreach($arResult["HIDDEN"] as $arItem):?>
			<input type="hidden" name="<?echo $arItem["CONTROL_NAME"]?>" id="<?echo $arItem["CONTROL_ID"]?>" value="<?echo $arItem["HTML_VALUE"]?>" />
			<?endforeach;?>
			<div class="row">
				<?foreach($arResult["ITEMS"] as $key=>$arItem)//prices
				{
					$key = $arItem["ENCODED_ID"];
					if(isset($arItem["PRICE"])):
						if ($arItem["VALUES"]["MAX"]["VALUE"] - $arItem["VALUES"]["MIN"]["VALUE"] <= 0)
							continue;

						$step_num = 4;
						$step = ($arItem["VALUES"]["MAX"]["VALUE"] - $arItem["VALUES"]["MIN"]["VALUE"]) / $step_num;
						$prices = array();
						if (Bitrix\Main\Loader::includeModule("currency"))
						{
							for ($i = 0; $i < $step_num; $i++)
							{
								$prices[$i] = CCurrencyLang::CurrencyFormat($arItem["VALUES"]["MIN"]["VALUE"] + $step*$i, $arItem["VALUES"]["MIN"]["CURRENCY"], false);
							}
							$prices[$step_num] = CCurrencyLang::CurrencyFormat($arItem["VALUES"]["MAX"]["VALUE"], $arItem["VALUES"]["MAX"]["CURRENCY"], false);
						}
						else
						{
							$precision = $arItem["DECIMALS"]? $arItem["DECIMALS"]: 0;
							for ($i = 0; $i < $step_num; $i++)
							{
								$prices[$i] = number_format($arItem["VALUES"]["MIN"]["VALUE"] + $step*$i, $precision, ".", "");
							}
							$prices[$step_num] = number_format($arItem["VALUES"]["MAX"]["VALUE"], $precision, ".", "");
						}
						?>
						<div class="<?if ($arParams["FILTER_VIEW_MODE"] == "HORIZONTAL"):?>col-sm-6 col-md-4<?else:?>col-lg-12<?endif?> bx-filter-parameters-box bx-active">
							<span class="bx-filter-container-modef"></span>
							<div class="bx-filter-parameters-box-title" onclick="smartFilter.hideFilterProps(this)"><span><?=$arItem["NAME"]?> <i data-role="prop_angle" class="fa fa-angle-<?if ($arItem["DISPLAY_EXPANDED"]== "Y"):?>up<?else:?>down<?endif?>"></i></span></div>
							<div class="bx-filter-block" data-role="bx_filter_block">
								<div class="row bx-filter-parameters-box-container">
									<div class="col-xs-6 bx-filter-parameters-box-container-block bx-left">
										<i class="bx-ft-sub"><?=GetMessage("CT_BCSF_FILTER_FROM")?></i>
										<div class="bx-filter-input-container">
											<input
												class="min-price"
												type="text"
												name="<?echo $arItem["VALUES"]["MIN"]["CONTROL_NAME"]?>"
												id="<?echo $arItem["VALUES"]["MIN"]["CONTROL_ID"]?>"
												value="<?echo $arItem["VALUES"]["MIN"]["HTML_VALUE"]?>"
												size="5"
												onkeyup="smartFilter.keyup(this)"
											/>
										</div>
									</div>
									<div class="col-xs-6 bx-filter-parameters-box-container-block bx-right">
										<i class="bx-ft-sub"><?=GetMessage("CT_BCSF_FILTER_TO")?></i>
										<div class="bx-filter-input-container">
											<input
												class="max-price"
												type="text"
												name="<?echo $arItem["VALUES"]["MAX"]["CONTROL_NAME"]?>"
												id="<?echo $arItem["VALUES"]["MAX"]["CONTROL_ID"]?>"
												value="<?echo $arItem["VALUES"]["MAX"]["HTML_VALUE"]?>"
												size="5"
												onkeyup="smartFilter.keyup(this)"
											/>
										</div>
									</div>

									<div class="col-xs-10 col-xs-offset-1 bx-ui-slider-track-container">
										<div class="bx-ui-slider-track" id="drag_track_<?=$key?>">
											<?for($i = 0; $i <= $step_num; $i++):?>
											<div class="bx-ui-slider-part p<?=$i+1?>"><span><?=$prices[$i]?></span></div>
											<?endfor;?>

											<div class="bx-ui-slider-pricebar-vd" style="left: 0;right: 0;" id="colorUnavailableActive_<?=$key?>"></div>
											<div class="bx-ui-slider-pricebar-vn" style="left: 0;right: 0;" id="colorAvailableInactive_<?=$key?>"></div>
											<div class="bx-ui-slider-pricebar-v"  style="left: 0;right: 0;" id="colorAvailableActive_<?=$key?>"></div>
											<div class="bx-ui-slider-range" id="drag_tracker_<?=$key?>"  style="left: 0%; right: 0%;">
												<a class="bx-ui-slider-handle left"  style="left:0;" href="javascript:void(0)" id="left_slider_<?=$key?>"></a>
												<a class="bx-ui-slider-handle right" style="right:0;" href="javascript:void(0)" id="right_slider_<?=$key?>"></a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?
						$arJsParams = array(
							"leftSlider" => 'left_slider_'.$key,
							"rightSlider" => 'right_slider_'.$key,
							"tracker" => "drag_tracker_".$key,
							"trackerWrap" => "drag_track_".$key,
							"minInputId" => $arItem["VALUES"]["MIN"]["CONTROL_ID"],
							"maxInputId" => $arItem["VALUES"]["MAX"]["CONTROL_ID"],
							"minPrice" => $arItem["VALUES"]["MIN"]["VALUE"],
							"maxPrice" => $arItem["VALUES"]["MAX"]["VALUE"],
							"curMinPrice" => $arItem["VALUES"]["MIN"]["HTML_VALUE"],
							"curMaxPrice" => $arItem["VALUES"]["MAX"]["HTML_VALUE"],
							"fltMinPrice" => intval($arItem["VALUES"]["MIN"]["FILTERED_VALUE"]) ? $arItem["VALUES"]["MIN"]["FILTERED_VALUE"] : $arItem["VALUES"]["MIN"]["VALUE"] ,
							"fltMaxPrice" => intval($arItem["VALUES"]["MAX"]["FILTERED_VALUE"]) ? $arItem["VALUES"]["MAX"]["FILTERED_VALUE"] : $arItem["VALUES"]["MAX"]["VALUE"],
							"precision" => $precision,
							"colorUnavailableActive" => 'colorUnavailableActive_'.$key,
							"colorAvailableActive" => 'colorAvailableActive_'.$key,
							"colorAvailableInactive" => 'colorAvailableInactive_'.$key,
						);
						?>
						<script type="text/javascript">
							BX.ready(function(){
								window['trackBar<?=$key?>'] = new BX.Iblock.SmartFilter(<?=CUtil::PhpToJSObject($arJsParams)?>);
							});
						</script>
					<?endif;
				}

				//not prices
				foreach($arResult["ITEMS"] as $key=>$arItem)
				{
					if(
						empty($arItem["VALUES"])
						|| isset($arItem["PRICE"])
					)
						continue;

					if (
						$arItem["DISPLAY_TYPE"] == "A"
						&& (
							$arItem["VALUES"]["MAX"]["VALUE"] - $arItem["VALUES"]["MIN"]["VALUE"] <= 0
						)
					)
						continue;
					?>
					<div class="<?if ($arParams["FILTER_VIEW_MODE"] == "HORIZONTAL"):?>col-sm-6 col-md-4<?else:?>col-lg-12<?endif?> bx-filter-parameters-box <?if ($arItem["DISPLAY_EXPANDED"]== "Y"):?>bx-active<?endif?>">
						<span class="bx-filter-container-modef"></span>
						<div class="bx-filter-parameters-box-title" onclick="smartFilter.hideFilterProps(this)">
							<span class="bx-filter-parameters-box-hint"><?=$arItem["NAME"]?>
								<?if ($arItem["FILTER_HINT"] <> ""):?>
									<i id="item_title_hint_<?echo $arItem["ID"]?>" class="fa fa-question-circle"></i>
									<script type="text/javascript">
										new top.BX.CHint({
											parent: top.BX("item_title_hint_<?echo $arItem["ID"]?>"),
											show_timeout: 10,
											hide_timeout: 200,
											dx: 2,
											preventHide: true,
											min_width: 250,
											hint: '<?= CUtil::JSEscape($arItem["FILTER_HINT"])?>'
										});
									</script>
								<?endif?>
								<i data-role="prop_angle" class="fa fa-angle-<?if ($arItem["DISPLAY_EXPANDED"]== "Y"):?>up<?else:?>down<?endif?>"></i>
							</span>
						</div>

						<div class="bx-filter-block" data-role="bx_filter_block">
							<div class="row bx-filter-parameters-box-container">
							<?
							$arCur = current($arItem["VALUES"]);
							switch ($arItem["DISPLAY_TYPE"])
							{
								case "A"://NUMBERS_WITH_SLIDER
									?>
									<div class="col-xs-6 bx-filter-parameters-box-container-block bx-left">
										<i class="bx-ft-sub"><?=GetMessage("CT_BCSF_FILTER_FROM")?></i>
										<div class="bx-filter-input-container">
											<input
												class="min-price"
												type="text"
												name="<?echo $arItem["VALUES"]["MIN"]["CONTROL_NAME"]?>"
												id="<?echo $arItem["VALUES"]["MIN"]["CONTROL_ID"]?>"
												value="<?echo $arItem["VALUES"]["MIN"]["HTML_VALUE"]?>"
												size="5"
												onkeyup="smartFilter.keyup(this)"
											/>
										</div>
									</div>
									<div class="col-xs-6 bx-filter-parameters-box-container-block bx-right">
										<i class="bx-ft-sub"><?=GetMessage("CT_BCSF_FILTER_TO")?></i>
										<div class="bx-filter-input-container">
											<input
												class="max-price"
												type="text"
												name="<?echo $arItem["VALUES"]["MAX"]["CONTROL_NAME"]?>"
												id="<?echo $arItem["VALUES"]["MAX"]["CONTROL_ID"]?>"
												value="<?echo $arItem["VALUES"]["MAX"]["HTML_VALUE"]?>"
												size="5"
												onkeyup="smartFilter.keyup(this)"
											/>
										</div>
									</div>

									<div class="col-xs-10 col-xs-offset-1 bx-ui-slider-track-container">
										<div class="bx-ui-slider-track" id="drag_track_<?=$key?>">
											<?
											$precision = $arItem["DECIMALS"]? $arItem["DECIMALS"]: 0;
											$step = ($arItem["VALUES"]["MAX"]["VALUE"] - $arItem["VALUES"]["MIN"]["VALUE"]) / 4;
											$value1 = number_format($arItem["VALUES"]["MIN"]["VALUE"], $precision, ".", "");
											$value2 = number_format($arItem["VALUES"]["MIN"]["VALUE"] + $step, $precision, ".", "");
											$value3 = number_format($arItem["VALUES"]["MIN"]["VALUE"] + $step * 2, $precision, ".", "");
											$value4 = number_format($arItem["VALUES"]["MIN"]["VALUE"] + $step * 3, $precision, ".", "");
											$value5 = number_format($arItem["VALUES"]["MAX"]["VALUE"], $precision, ".", "");
											?>
											<div class="bx-ui-slider-part p1"><span><?=$value1?></span></div>
											<div class="bx-ui-slider-part p2"><span><?=$value2?></span></div>
											<div class="bx-ui-slider-part p3"><span><?=$value3?></span></div>
											<div class="bx-ui-slider-part p4"><span><?=$value4?></span></div>
											<div class="bx-ui-slider-part p5"><span><?=$value5?></span></div>

											<div class="bx-ui-slider-pricebar-vd" style="left: 0;right: 0;" id="colorUnavailableActive_<?=$key?>"></div>
											<div class="bx-ui-slider-pricebar-vn" style="left: 0;right: 0;" id="colorAvailableInactive_<?=$key?>"></div>
											<div class="bx-ui-slider-pricebar-v"  style="left: 0;right: 0;" id="colorAvailableActive_<?=$key?>"></div>
											<div class="bx-ui-slider-range" 	id="drag_tracker_<?=$key?>"  style="left: 0;right: 0;">
												<a class="bx-ui-slider-handle left"  style="left:0;" href="javascript:void(0)" id="left_slider_<?=$key?>"></a>
												<a class="bx-ui-slider-handle right" style="right:0;" href="javascript:void(0)" id="right_slider_<?=$key?>"></a>
											</div>
										</div>
									</div>
									<?
									$arJsParams = array(
										"leftSlider" => 'left_slider_'.$key,
										"rightSlider" => 'right_slider_'.$key,
										"tracker" => "drag_tracker_".$key,
										"trackerWrap" => "drag_track_".$key,
										"minInputId" => $arItem["VALUES"]["MIN"]["CONTROL_ID"],
										"maxInputId" => $arItem["VALUES"]["MAX"]["CONTROL_ID"],
										"minPrice" => $arItem["VALUES"]["MIN"]["VALUE"],
										"maxPrice" => $arItem["VALUES"]["MAX"]["VALUE"],
										"curMinPrice" => $arItem["VALUES"]["MIN"]["HTML_VALUE"],
										"curMaxPrice" => $arItem["VALUES"]["MAX"]["HTML_VALUE"],
										"fltMinPrice" => intval($arItem["VALUES"]["MIN"]["FILTERED_VALUE"]) ? $arItem["VALUES"]["MIN"]["FILTERED_VALUE"] : $arItem["VALUES"]["MIN"]["VALUE"] ,
										"fltMaxPrice" => intval($arItem["VALUES"]["MAX"]["FILTERED_VALUE"]) ? $arItem["VALUES"]["MAX"]["FILTERED_VALUE"] : $arItem["VALUES"]["MAX"]["VALUE"],
										"precision" => $arItem["DECIMALS"]? $arItem["DECIMALS"]: 0,
										"colorUnavailableActive" => 'colorUnavailableActive_'.$key,
										"colorAvailableActive" => 'colorAvailableActive_'.$key,
										"colorAvailableInactive" => 'colorAvailableInactive_'.$key,
									);
									?>
									<script type="text/javascript">
										BX.ready(function(){
											window['trackBar<?=$key?>'] = new BX.Iblock.SmartFilter(<?=CUtil::PhpToJSObject($arJsParams)?>);
										});
									</script>
									<?
									break;
								case "B"://NUMBERS
									?>
									<div class="col-xs-6 bx-filter-parameters-box-container-block bx-left">
										<i class="bx-ft-sub"><?=GetMessage("CT_BCSF_FILTER_FROM")?></i>
										<div class="bx-filter-input-container">
											<input
												class="min-price"
												type="text"
												name="<?echo $arItem["VALUES"]["MIN"]["CONTROL_NAME"]?>"
												id="<?echo $arItem["VALUES"]["MIN"]["CONTROL_ID"]?>"
												value="<?echo $arItem["VALUES"]["MIN"]["HTML_VALUE"]?>"
												size="5"
												onkeyup="smartFilter.keyup(this)"
												/>
										</div>
									</div>
									<div class="col-xs-6 bx-filter-parameters-box-container-block bx-right">
										<i class="bx-ft-sub"><?=GetMessage("CT_BCSF_FILTER_TO")?></i>
										<div class="bx-filter-input-container">
											<input
												class="max-price"
												type="text"
												name="<?echo $arItem["VALUES"]["MAX"]["CONTROL_NAME"]?>"
												id="<?echo $arItem["VALUES"]["MAX"]["CONTROL_ID"]?>"
												value="<?echo $arItem["VALUES"]["MAX"]["HTML_VALUE"]?>"
												size="5"
												onkeyup="smartFilter.keyup(this)"
												/>
										</div>
									</div>
									<?
									break;
								case "G"://CHECKBOXES_WITH_PICTURES
									?>
									<div class="col-xs-12">
										<div class="bx-filter-param-btn-inline">
										<?foreach ($arItem["VALUES"] as $val => $ar):?>
											<input
												style="display: none"
												type="checkbox"
												name="<?=$ar["CONTROL_NAME"]?>"
												id="<?=$ar["CONTROL_ID"]?>"
												value="<?=$ar["HTML_VALUE"]?>"
												<? echo $ar["CHECKED"]? 'checked="checked"': '' ?>
											/>
											<?
											$class = "";
											if ($ar["CHECKED"])
												$class.= " bx-active";
											if ($ar["DISABLED"])
												$class.= " disabled";
											?>
											<label for="<?=$ar["CONTROL_ID"]?>" data-role="label_<?=$ar["CONTROL_ID"]?>" class="bx-filter-param-label <?=$class?>" onclick="smartFilter.keyup(BX('<?=CUtil::JSEscape($ar["CONTROL_ID"])?>')); BX.toggleClass(this, 'bx-active');">
												<span class="bx-filter-param-btn bx-color-sl">
													<?if (isset($ar["FILE"]) && !empty($ar["FILE"]["SRC"])):?>
													<span class="bx-filter-btn-color-icon" style="background-image:url('<?=$ar["FILE"]["SRC"]?>');"></span>
													<?endif?>
												</span>
											</label>
										<?endforeach?>
										</div>
									</div>
									<?
									break;
								case "H"://CHECKBOXES_WITH_PICTURES_AND_LABELS
									?>
									<div class="col-xs-12">
										<div class="bx-filter-param-btn-block">
										<?foreach ($arItem["VALUES"] as $val => $ar):?>
											<input
												style="display: none"
												type="checkbox"
												name="<?=$ar["CONTROL_NAME"]?>"
												id="<?=$ar["CONTROL_ID"]?>"
												value="<?=$ar["HTML_VALUE"]?>"
												<? echo $ar["CHECKED"]? 'checked="checked"': '' ?>
											/>
											<?
											$class = "";
											if ($ar["CHECKED"])
												$class.= " bx-active";
											if ($ar["DISABLED"])
												$class.= " disabled";
											?>
											<label for="<?=$ar["CONTROL_ID"]?>" data-role="label_<?=$ar["CONTROL_ID"]?>" class="bx-filter-param-label<?=$class?>" onclick="smartFilter.keyup(BX('<?=CUtil::JSEscape($ar["CONTROL_ID"])?>')); BX.toggleClass(this, 'bx-active');">
												<span class="bx-filter-param-btn bx-color-sl">
													<?if (isset($ar["FILE"]) && !empty($ar["FILE"]["SRC"])):?>
														<span class="bx-filter-btn-color-icon" style="background-image:url('<?=$ar["FILE"]["SRC"]?>');"></span>
													<?endif?>
												</span>
												<span class="bx-filter-param-text" title="<?=$ar["VALUE"];?>"><?=$ar["VALUE"];?><?
												if ($arParams["DISPLAY_ELEMENT_COUNT"] !== "N" && isset($ar["ELEMENT_COUNT"])):
													?> (<span data-role="count_<?=$ar["CONTROL_ID"]?>"><? echo $ar["ELEMENT_COUNT"]; ?></span>)<?
												endif;?></span>
											</label>
										<?endforeach?>
										</div>
									</div>
									<?
									break;
								case "P"://DROPDOWN
									$checkedItemExist = false;
									?>
									<div class="col-xs-12">
										<div class="bx-filter-select-container">
											<div class="bx-filter-select-block" onclick="smartFilter.showDropDownPopup(this, '<?=CUtil::JSEscape($key)?>')">
												<div class="bx-filter-select-text" data-role="currentOption">
													<?
													foreach ($arItem["VALUES"] as $val => $ar)
													{
														if ($ar["CHECKED"])
														{
															echo $ar["VALUE"];
															$checkedItemExist = true;
														}
													}
													if (!$checkedItemExist)
													{
														echo GetMessage("CT_BCSF_FILTER_ALL");
													}
													?>
												</div>
												<div class="bx-filter-select-arrow"></div>
												<input
													style="display: none"
													type="radio"
													name="<?=$arCur["CONTROL_NAME_ALT"]?>"
													id="<? echo "all_".$arCur["CONTROL_ID"] ?>"
													value=""
												/>
												<?foreach ($arItem["VALUES"] as $val => $ar):?>
													<input
														style="display: none"
														type="radio"
														name="<?=$ar["CONTROL_NAME_ALT"]?>"
														id="<?=$ar["CONTROL_ID"]?>"
														value="<? echo $ar["HTML_VALUE_ALT"] ?>"
														<? echo $ar["CHECKED"]? 'checked="checked"': '' ?>
													/>
												<?endforeach?>
												<div class="bx-filter-select-popup" data-role="dropdownContent" style="display: none;">
													<ul>
														<li>
															<label for="<?="all_".$arCur["CONTROL_ID"]?>" class="bx-filter-param-label" data-role="label_<?="all_".$arCur["CONTROL_ID"]?>" onclick="smartFilter.selectDropDownItem(this, '<?=CUtil::JSEscape("all_".$arCur["CONTROL_ID"])?>')">
																<? echo GetMessage("CT_BCSF_FILTER_ALL"); ?>
															</label>
														</li>
													<?
													foreach ($arItem["VALUES"] as $val => $ar):
														$class = "";
														if ($ar["CHECKED"])
															$class.= " selected";
														if ($ar["DISABLED"])
															$class.= " disabled";
													?>
														<li>
															<label for="<?=$ar["CONTROL_ID"]?>" class="bx-filter-param-label<?=$class?>" data-role="label_<?=$ar["CONTROL_ID"]?>" onclick="smartFilter.selectDropDownItem(this, '<?=CUtil::JSEscape($ar["CONTROL_ID"])?>')"><?=$ar["VALUE"]?></label>
														</li>
													<?endforeach?>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<?
									break;
								case "R"://DROPDOWN_WITH_PICTURES_AND_LABELS
									?>
									<div class="col-xs-12">
										<div class="bx-filter-select-container">
											<div class="bx-filter-select-block" onclick="smartFilter.showDropDownPopup(this, '<?=CUtil::JSEscape($key)?>')">
												<div class="bx-filter-select-text fix" data-role="currentOption">
													<?
													$checkedItemExist = false;
													foreach ($arItem["VALUES"] as $val => $ar):
														if ($ar["CHECKED"])
														{
														?>
															<?if (isset($ar["FILE"]) && !empty($ar["FILE"]["SRC"])):?>
																<span class="bx-filter-btn-color-icon" style="background-image:url('<?=$ar["FILE"]["SRC"]?>');"></span>
															<?endif?>
															<span class="bx-filter-param-text">
																<?=$ar["VALUE"]?>
															</span>
														<?
															$checkedItemExist = true;
														}
													endforeach;
													if (!$checkedItemExist)
													{
														?><span class="bx-filter-btn-color-icon all"></span> <?
														echo GetMessage("CT_BCSF_FILTER_ALL");
													}
													?>
												</div>
												<div class="bx-filter-select-arrow"></div>
												<input
													style="display: none"
													type="radio"
													name="<?=$arCur["CONTROL_NAME_ALT"]?>"
													id="<? echo "all_".$arCur["CONTROL_ID"] ?>"
													value=""
												/>
												<?foreach ($arItem["VALUES"] as $val => $ar):?>
													<input
														style="display: none"
														type="radio"
														name="<?=$ar["CONTROL_NAME_ALT"]?>"
														id="<?=$ar["CONTROL_ID"]?>"
														value="<?=$ar["HTML_VALUE_ALT"]?>"
														<? echo $ar["CHECKED"]? 'checked="checked"': '' ?>
													/>
												<?endforeach?>
												<div class="bx-filter-select-popup" data-role="dropdownContent" style="display: none">
													<ul>
														<li style="border-bottom: 1px solid #e5e5e5;padding-bottom: 5px;margin-bottom: 5px;">
															<label for="<?="all_".$arCur["CONTROL_ID"]?>" class="bx-filter-param-label" data-role="label_<?="all_".$arCur["CONTROL_ID"]?>" onclick="smartFilter.selectDropDownItem(this, '<?=CUtil::JSEscape("all_".$arCur["CONTROL_ID"])?>')">
																<span class="bx-filter-btn-color-icon all"></span>
																<? echo GetMessage("CT_BCSF_FILTER_ALL"); ?>
															</label>
														</li>
													<?
													foreach ($arItem["VALUES"] as $val => $ar):
														$class = "";
														if ($ar["CHECKED"])
															$class.= " selected";
														if ($ar["DISABLED"])
															$class.= " disabled";
													?>
														<li>
															<label for="<?=$ar["CONTROL_ID"]?>" data-role="label_<?=$ar["CONTROL_ID"]?>" class="bx-filter-param-label<?=$class?>" onclick="smartFilter.selectDropDownItem(this, '<?=CUtil::JSEscape($ar["CONTROL_ID"])?>')">
																<?if (isset($ar["FILE"]) && !empty($ar["FILE"]["SRC"])):?>
																	<span class="bx-filter-btn-color-icon" style="background-image:url('<?=$ar["FILE"]["SRC"]?>');"></span>
																<?endif?>
																<span class="bx-filter-param-text">
																	<?=$ar["VALUE"]?>
																</span>
															</label>
														</li>
													<?endforeach?>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<?
									break;
								case "K"://RADIO_BUTTONS
									?>
									<div class="col-xs-12">
										<div class="radio">
											<label class="bx-filter-param-label" for="<? echo "all_".$arCur["CONTROL_ID"] ?>">
												<span class="bx-filter-input-checkbox">
													<input
														type="radio"
														value=""
														name="<? echo $arCur["CONTROL_NAME_ALT"] ?>"
														id="<? echo "all_".$arCur["CONTROL_ID"] ?>"
														onclick="smartFilter.click(this)"
													/>
													<span class="bx-filter-param-text"><? echo GetMessage("CT_BCSF_FILTER_ALL"); ?></span>
												</span>
											</label>
										</div>
										<?foreach($arItem["VALUES"] as $val => $ar):?>
											<div class="radio">
												<label data-role="label_<?=$ar["CONTROL_ID"]?>" class="bx-filter-param-label" for="<? echo $ar["CONTROL_ID"] ?>">
													<span class="bx-filter-input-checkbox <? echo $ar["DISABLED"] ? 'disabled': '' ?>">
														<input
															type="radio"
															value="<? echo $ar["HTML_VALUE_ALT"] ?>"
															name="<? echo $ar["CONTROL_NAME_ALT"] ?>"
															id="<? echo $ar["CONTROL_ID"] ?>"
															<? echo $ar["CHECKED"]? 'checked="checked"': '' ?>
															onclick="smartFilter.click(this)"
														/>
														<span class="bx-filter-param-text" title="<?=$ar["VALUE"];?>"><?=$ar["VALUE"];?><?
														if ($arParams["DISPLAY_ELEMENT_COUNT"] !== "N" && isset($ar["ELEMENT_COUNT"])):
															?>&nbsp;(<span data-role="count_<?=$ar["CONTROL_ID"]?>"><? echo $ar["ELEMENT_COUNT"]; ?></span>)<?
														endif;?></span>
													</span>
												</label>
											</div>
										<?endforeach;?>
									</div>
									<?
									break;
								case "U"://CALENDAR
									?>
									<div class="col-xs-12">
										<div class="bx-filter-parameters-box-container-block"><div class="bx-filter-input-container bx-filter-calendar-container">
											<?$APPLICATION->IncludeComponent(
												'bitrix:main.calendar',
												'',
												array(
													'FORM_NAME' => $arResult["FILTER_NAME"]."_form",
													'SHOW_INPUT' => 'Y',
													'INPUT_ADDITIONAL_ATTR' => 'class="calendar" placeholder="'.FormatDate("SHORT", $arItem["VALUES"]["MIN"]["VALUE"]).'" onkeyup="smartFilter.keyup(this)" onchange="smartFilter.keyup(this)"',
													'INPUT_NAME' => $arItem["VALUES"]["MIN"]["CONTROL_NAME"],
													'INPUT_VALUE' => $arItem["VALUES"]["MIN"]["HTML_VALUE"],
													'SHOW_TIME' => 'N',
													'HIDE_TIMEBAR' => 'Y',
												),
												null,
												array('HIDE_ICONS' => 'Y')
											);?>
										</div></div>
										<div class="bx-filter-parameters-box-container-block"><div class="bx-filter-input-container bx-filter-calendar-container">
											<?$APPLICATION->IncludeComponent(
												'bitrix:main.calendar',
												'',
												array(
													'FORM_NAME' => $arResult["FILTER_NAME"]."_form",
													'SHOW_INPUT' => 'Y',
													'INPUT_ADDITIONAL_ATTR' => 'class="calendar" placeholder="'.FormatDate("SHORT", $arItem["VALUES"]["MAX"]["VALUE"]).'" onkeyup="smartFilter.keyup(this)" onchange="smartFilter.keyup(this)"',
													'INPUT_NAME' => $arItem["VALUES"]["MAX"]["CONTROL_NAME"],
													'INPUT_VALUE' => $arItem["VALUES"]["MAX"]["HTML_VALUE"],
													'SHOW_TIME' => 'N',
													'HIDE_TIMEBAR' => 'Y',
												),
												null,
												array('HIDE_ICONS' => 'Y')
											);?>
										</div></div>
									</div>
									<?
									break;
								default://CHECKBOXES
									?>
									<div class="col-xs-12">
										<?foreach($arItem["VALUES"] as $val => $ar):?>
											<div class="checkbox">
												<label data-role="label_<?=$ar["CONTROL_ID"]?>" class="bx-filter-param-label <? echo $ar["DISABLED"] ? 'disabled': '' ?>" for="<? echo $ar["CONTROL_ID"] ?>">
													<span class="bx-filter-input-checkbox">
														<input
															type="checkbox"
															value="<? echo $ar["HTML_VALUE"] ?>"
															name="<? echo $ar["CONTROL_NAME"] ?>"
															id="<? echo $ar["CONTROL_ID"] ?>"
															<? echo $ar["CHECKED"]? 'checked="checked"': '' ?>
															onclick="smartFilter.click(this)"
														/>
														<span class="bx-filter-param-text" title="<?=$ar["VALUE"];?>"><?=$ar["VALUE"];?><?
														if ($arParams["DISPLAY_ELEMENT_COUNT"] !== "N" && isset($ar["ELEMENT_COUNT"])):
															?>&nbsp;(<span data-role="count_<?=$ar["CONTROL_ID"]?>"><? echo $ar["ELEMENT_COUNT"]; ?></span>)<?
														endif;?></span>
													</span>
												</label>
											</div>
										<?endforeach;?>
									</div>
							<?
							}
							?>
							</div>
							<div style="clear: both"></div>
						</div>
					</div>
				<?
				}
				?>
			</div><!--//row-->
			<div class="row">
				<div class="col-xs-12 bx-filter-button-box">
					<div class="bx-filter-block">
						<div class="bx-filter-parameters-box-container">
							<input
								class="btn btn-themes"
								type="submit"
								id="set_filter"
								name="set_filter"
								value="<?=GetMessage("CT_BCSF_SET_FILTER")?>"
							/>
							<input
								class="btn btn-link"
								type="submit"
								id="del_filter"
								name="del_filter"
								value="<?=GetMessage("CT_BCSF_DEL_FILTER")?>"
							/>
							<div class="bx-filter-popup-result <?if ($arParams["FILTER_VIEW_MODE"] == "VERTICAL") echo $arParams["POPUP_POSITION"]?>" id="modef" <?if(!isset($arResult["ELEMENT_COUNT"])) echo 'style="display:none"';?> style="display: inline-block;">
								<?echo GetMessage("CT_BCSF_FILTER_COUNT", array("#ELEMENT_COUNT#" => '<span id="modef_num">'.intval($arResult["ELEMENT_COUNT"]).'</span>'));?>
								<span class="arrow"></span>
								<br/>
								<a href="<?echo $arResult["FILTER_URL"]?>" target=""><?echo GetMessage("CT_BCSF_FILTER_SHOW")?></a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="clb"></div>
		</form>
	</div>
</div>
<script type="text/javascript">
	var smartFilter = new JCSmartFilter('<?echo CUtil::JSEscape($arResult["FORM_ACTION"])?>', '<?=CUtil::JSEscape($arParams["FILTER_VIEW_MODE"])?>', <?=CUtil::PhpToJSObject($arResult["JS_FILTER_PARAMS"])?>);
</script>















<div class="header-menu mb--hidden">
	<ul class="header-menu-list">
	<?
	$previousLevel = 0;
	// echo "<pre>";
// var_dump($arResult);
// echo "</pre>";	
	foreach($arResult as $arItem):
	?>
	<?/*echo "<pre>";
var_dump($arItem);
echo "</pre>"*/?>	
		<?if ($previousLevel && $arItem["DEPTH_LEVEL"] < $previousLevel):?>
			<?=str_repeat("</li>", ($previousLevel - $arItem["DEPTH_LEVEL"]));?>
		<?endif?>

		<?if ($arItem["IS_PARENT"]):?>
				<li<?if($arItem["CHILD_SELECTED"] !== true):?> class="header-menu_item"<?endif?>>
					<a  class="header-menu_link has--child" href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?>
                        <svg class="arrow-down_icon">
                            <use href="assets/img/svg-icons.svg#arrow-down"></use>
                        </svg>
                    </a>
					<div class="menu-child">
						<ul class="menu-child-list">
						
							<li class="menu-child_item"><a href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?></a></li>												
					
					</div>
					

		<?else:?>

			<?if ($arItem["PERMISSION"] > "D"):?>
					<li class="header-menu_item"><a href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?></a></li>
			<?endif?>

		<?endif?>

		<?$previousLevel = $arItem["DEPTH_LEVEL"];?>

	<?endforeach?>

	<?if ($previousLevel > 1)://close last item tags?>
		<?=str_repeat("</ul></li>", ($previousLevel-1) );?>
	<?endif?>

	</ul>
	</div>
<?endif?>





<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>




<?if (!empty($arResult)):?>




<div class="header-menu mb--hidden">
	<ul class="header-menu-list">
	<?
	$arItem = reset($arResult);
	$D_L = $arItem["DEPTH_LEVEL"];
	$D_L2 = $arItem["DEPTH_LEVEL"];
	foreach($arResult as $arItem):
	//echo var_dump($arItem);
		
		if ($arItem["DEPTH_LEVEL"]==$D_L && $arItem["IS_PARENT"]==false){?>
			
				<li class="header-menu_item"><a href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?></a></li>
				
	<?} elseif ($arItem["DEPTH_LEVEL"]==$D_L && $arItem["IS_PARENT"]==true){ ?>
		<li class="header-menu_item"><a class="header-menu_link has--child" href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?>
			<svg class="arrow-down_icon">
                <use href="assets/img/svg-icons.svg#arrow-down"></use>
            </svg>
			</a>
			<div class="menu-child">
				<ul  class="menu-child-list">
	
	<?} elseif ($arItem["DEPTH_LEVEL"]>$D_L){ ?>
					<li class="menu-child_item"><a href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?></a></li>
	
	<?} elseif ($arItem["DEPTH_LEVEL"]<$D_L && $arItem["IS_PARENT"]==false){ ?>
					</ul></div></li>
		<li class="header-menu_item"><a href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?></a></li>
		<? $D_L -= 1; ?>
	<?}?>
		<? $D_L = $arItem["DEPTH_LEVEL"]; ?>

<?endforeach?>
</ul></div>
<?endif?>











                <div class="index-catalog-list">
                    <div class="index-catalog-item catalog-img">
                        <a href="#"><img src="assets\img\Sakura-logo.svg" alt=""></a>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Телевизоры, аудио, видео</a>
                        <div class="index-catalog-submenu">
                            <div class="catalog-submenu__inner">
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Крупная бытовая техника</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Вытяжки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Духовки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Холодильники</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посудомоечные машины</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Винные шкафы</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Мелкая бытовая техника</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Аэрогрили</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Блендеры</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Блинницы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Вафельницы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Мясорубки</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Посуда и аксессуары</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посуда для приготовления</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Аксессуары для готовки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Казаны</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Кастрюли</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Крышки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Мантоварки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Наборы посуды</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Ножи</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посуда для духовки и СВЧ</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Разделочные доски</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Сковороды</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Формы для выпечки</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Сервировка</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Графины</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Заварники и кофейники</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Наборы для специй</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Сахарницы и масленки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Кружки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посуда для детей</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Салатники</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Сервизы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Столовые приборы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Tарелки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Фужеры и бокалы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Подносы</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Инструменты</a>
                        <div class="index-catalog-submenu">
                            <div class="catalog-submenu__inner">
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Крупная бытовая техника</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Вытяжки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Духовки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Холодильники</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посудомоечные машины</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Винные шкафы</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Мелкая бытовая техника</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Аэрогрили</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Блендеры</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Блинницы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Вафельницы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Мясорубки</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Посуда и аксессуары</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посуда для приготовления</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Аксессуары для готовки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Казаны</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Кастрюли</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Крышки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Мантоварки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Наборы посуды</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Ножи</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посуда для духовки и СВЧ</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Разделочные доски</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Сковороды</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Формы для выпечки</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Сервировка</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Графины</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Заварники и кофейники</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Наборы для специй</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Сахарницы и масленки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Кружки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посуда для детей</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Салатники</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Сервизы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Столовые приборы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Tарелки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Фужеры и бокалы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Подносы</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Красота и здоровье</a>
                        <div class="index-catalog-submenu">
                            <div class="catalog-submenu__inner">
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Крупная бытовая техника</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Вытяжки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Духовки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Холодильники</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посудомоечные машины</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Винные шкафы</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Мелкая бытовая техника</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Аэрогрили</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Блендеры</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Блинницы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Вафельницы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Мясорубки</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Посуда и аксессуары</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посуда для приготовления</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Аксессуары для готовки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Казаны</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Кастрюли</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Крышки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Мантоварки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Наборы посуды</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Ножи</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посуда для духовки и СВЧ</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Разделочные доски</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Сковороды</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Формы для выпечки</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Сервировка</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Графины</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Заварники и кофейники</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Наборы для специй</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Сахарницы и масленки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Кружки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Посуда для детей</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Салатники</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Сервизы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Столовые приборы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Tарелки</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Фужеры и бокалы</a>
                                        </div>
                                        <div class="catalog-submenu__item">
                                            <a href="#">Подносы</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Товары для авто</a>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Дача и сад</a>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Текстиль</a>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Товары для дома и кухни</a>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Техника для дома</a>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Техника для кухни</a>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link">Программное обеспечение</a>
                    </div>
                    <div class="index-catalog-item">
                        <a href="#" class="catalog-menu__link is-red">%Распродажа</a>
                    </div>
                </div>
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				<?print_r ("22222222");
echo "HI1";
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
    die();

use Bitrix\Main\Page\Asset;

CJSCore::Init(array('ajax', 'fx', 'popup'));

global $APPLICATION;
global $USER;
//global $isIndex, $isCatalog, $isDetail, $isCatalogCategories, $isAdditional, $isInstallCenters, $isServices, $hasContainer, $isOrderListing, $isResult;
//global $phone, $subtitle, $basket, $compare, $car, $current_step, $title, $arCities, $stage, $filter_list;

echo "HI2";
?>
<?echo "HI3";?>
<!DOCTYPE html>
<?echo "HI4";?>
<html class="no-js" lang="ru">
<head>
<?echo "HI5";?>
    <? $APPLICATION->ShowHead(); ?>
    <title>1<? //$APPLICATION->ShowTitle(); ?></title>
	
    
	
<?echo "HI6";?>
	<?
    Asset::getInstance()->addString('<meta charset="utf-8">');
echo "HI7";
    Asset::getInstance()->addString('<meta http-equiv="x-ua-compatible" content="ie=edge">');
echo "HI8";
    Asset::getInstance()->addString('<meta name="description" content="">');
echo "HI9";
    Asset::getInstance()->addString('<meta name="viewport" content="width=device-width, initial-scale=1">');
echo "HI10";
    Asset::getInstance()->addString('<link rel="preconnect" href="https://fonts.googleapis.com">');
echo "HI11";
    Asset::getInstance()->addString('<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>');
	
echo "HI12";
    Asset::getInstance()->addString('<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">');
    Asset::getInstance()->addString('<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">');
    Asset::getInstance()->addString('<link href="https://fonts.googleapis.com/css2?family=Exo:wght@400;500&display=swap" rel="stylesheet">');
	
echo "HI13";
    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/assets/css/animation.min.css");
    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/assets/css/normalize.min.css");
    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/assets/plugins/tinyslider/tiny-slider.min.css");
    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/assets/css/main.css");

echo "HI14";
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/assets/plugins/tinyslider/tiny-slider.min.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/assets/js/tabs.min.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/assets/js/main.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/assets/js/catalog.min.js');
	
	?>
	
<?echo "HI15";?>
</head>
<body id="body">

<div class="wrapper">

<?echo "HI16";?>
    <header class="header is-not-main" id="header">
        <div class="header-top">
            <div class="container">
                <div class="header-top-left mb--hidden">
                    <div class="header-social">
                        <ul class="header-social-list">
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--facebook">
                                        <use href="assets/img/svg-icons.svg#facebook"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--twitter">
                                        <use href="assets/img/svg-icons.svg#twitter"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--youtube">
                                        <use href="assets/img/svg-icons.svg#youtube"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--insta">
                                        <use href="assets/img/svg-icons.svg#instagram"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--telegram">
                                        <use href="assets/img/svg-icons.svg#telegram"></use>
                                    </svg>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <a href="#" target="_blank" class="header-slogan">Наши товары на маркетплейсах</a>
                </div>
                <a href="javascript:void(0);" class="header-mobile-burger header-catalog-burger mb--visible">
                    <i></i>
                </a>
                <div class="header-top-right">
                    <div class="header-menu mb--hidden">
                        <ul class="header-menu-list">
                            <li class="header-menu_item"><a class="header-menu_link" href="#">Акции</a></li>
                            <li class="header-menu_item"><a class="header-menu_link" href="#">Бренды</a></li>
                            <li class="header-menu_item"><a class="header-menu_link" href="#">Доставка и оплата</a></li>
                            <li class="header-menu_item">
                                <a class="header-menu_link has--child" href="#">
                                    Сервис
                                    <svg class="arrow-down_icon">
                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                    </svg>
                                </a>
                                <div class="menu-child">
                                    <ul class="menu-child-list">
                                        <li class="menu-child_item"><a href="#">Сервисные центры</a></li>
                                        <li class="menu-child_item"><a href="#">Правила гарантийного обслуживания</a></li>
                                    </ul>
                                </div>

                            </li>
                            <li class="header-menu_item">
                                <a class="header-menu_link has--child" href="#">
                                    О компании
                                    <svg class="arrow-down_icon">
                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                    </svg>
                                </a>
                                <div class="menu-child">
                                    <ul class="menu-child-list">
                                        <li class="menu-child_item"><a href="#">О компании</a></li>
                                        <li class="menu-child_item"><a href="#">Документы</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li class="header-menu_item"><a class="header-menu_link" href="#">Контакты</a></li>
                        </ul>
                    </div>
                    <a class="header-phone" href="tel:+73832119683">
                        <svg class="header-phone_icon">
                            <use href="assets/img/svg-icons.svg#header-phone"></use>
                        </svg>
                        +7 (383) 211 96 83
                    </a>
                </div>
            </div>
        </div>
        <div class="header-bottom">
            <div class="container">
                <a class="header-logo logo--big" href="/"><img src="assets/img/logo.svg" alt=""></a>
                <a class="header-logo logo--small" href="/"><img src="assets/img/logo-small.svg" alt=""></a>
                <a href="javascript:void(0);" class="header-catalog-btn button mb--hidden">
                        <span class="header-catalog-burger">
                            <i></i>
                        </span>
                    <span>Каталог</span>
                </a>
                <div class="header-menu is-scroll-visible mb--hidden">
                    <ul class="header-menu-list">
                        <li class="header-menu_item"><a class="header-menu_link" href="#">Акции</a></li>
                        <li class="header-menu_item"><a class="header-menu_link" href="#">Бренды</a></li>
                        <li class="header-menu_item"><a class="header-menu_link" href="#">Доставка и оплата</a></li>
                        <li class="header-menu_item">
                            <a class="header-menu_link has--child" href="#">
                                Сервис
                                <svg class="arrow-down_icon">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                            <div class="menu-child">
                                <ul class="menu-child-list">
                                    <li class="menu-child_item"><a href="#">Сервисные центры</a></li>
                                    <li class="menu-child_item"><a href="#">Правила гарантийного обслуживания</a></li>
                                </ul>
                            </div>

                        </li>
                        <li class="header-menu_item">
                            <a class="header-menu_link has--child" href="#">
                                О компании
                                <svg class="arrow-down_icon">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                            <div class="menu-child">
                                <ul class="menu-child-list">
                                    <li class="menu-child_item"><a href="#">О компании</a></li>
                                    <li class="menu-child_item"><a href="#">Документы</a></li>
                                </ul>
                            </div>
                        </li>
                        <li class="header-menu_item"><a class="header-menu_link" href="#">Контакты</a></li>
                    </ul>
                </div>
                <div class="header-catalog">
                    <div class="index-catalog-list">
                        <div class="index-catalog-item catalog-img mb--visible">
                            <a href="#" class="catalog-img_link">
                                <img src="assets\img\Sakura-logo.svg" alt="">
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link has--menu">
                                Телевизоры, аудио, видео
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                            <div class="index-catalog-submenu">
                                <div class="catalog-submenu__inner">
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Крупная бытовая техника</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Вытяжки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Духовки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Холодильники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посудомоечные машины
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Винные шкафы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Мелкая бытовая техника</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Аэрогрили
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Блендеры
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Блинницы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Вафельницы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Мясорубки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Посуда и аксессуары</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для приготовления
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Аксессуары для готовки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Казаны
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Кастрюли
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Крышки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Мантоварки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Наборы посуды
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Ножи
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для духовки и СВЧ
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Разделочные доски
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сковороды
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Формы для выпечки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Сервировка</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Графины
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Заварники и кофейники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Наборы для специй
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сахарницы и масленки</a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Кружки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для детей
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Салатники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сервизы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Столовые приборы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Tарелки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Фужеры и бокалы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Подносы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link has--menu">
                                Инструменты
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                            <div class="index-catalog-submenu">
                                <div class="catalog-submenu__inner">
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Крупная бытовая техника</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Вытяжки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Духовки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Холодильники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посудомоечные машины
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Винные шкафы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Мелкая бытовая техника</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Аэрогрили
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Блендеры
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Блинницы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Вафельницы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Мясорубки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Посуда и аксессуары</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для приготовления
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Аксессуары для готовки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Казаны
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Кастрюли
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Крышки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Мантоварки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Наборы посуды
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Ножи
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для духовки и СВЧ
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Разделочные доски
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сковороды
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Формы для выпечки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Сервировка</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Графины
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Заварники и кофейники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Наборы для специй
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сахарницы и масленки</a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Кружки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для детей
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Салатники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сервизы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Столовые приборы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Tарелки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Фужеры и бокалы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Подносы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Красота и здоровье
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Товары для авто
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Дача и сад
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Текстиль
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Товары для дома и кухни
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Техника для дома
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Техника для кухни
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Программное обеспечение
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link is-red">
                                %Распродажа
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="header-search">
                    <form class="search-form">
                        <input type="search" class="search-input" id="search-input" placeholder="Искать товары">
                        <button class="search-button">
                            <svg>
                                <use href="assets/img/svg-icons.svg#search-btn"></use>
                            </svg>
                        </button>
                        <a href="javascript:void(0);" class="is-scroll-visible search__icon">
                            <svg>
                                <use href="assets/img/svg-icons.svg#search-btn"></use>
                            </svg>
                        </a>
                    </form>
                </div>
                <div class="header-button-list">
                    <a href="#" class="header-compare header-button--flex">
                        <svg class="header-compare__icon header-button_icon">
                            <use href="assets/img/svg-icons.svg#compare"></use>
                        </svg>
                        <span>Сравнение</span>
                    </a>
                    <a href="#" class="header-favorite header-button--flex">
                        <svg class="header-favorite__icon header-button_icon">
                            <use href="assets/img/svg-icons.svg#favorite"></use>
                        </svg>
                        <span class="header-favorite__label" id="header-favorite">125</span>
                        <span>Избранное</span>
                    </a>
                    <a href="#" data-modal-target="enter" data-modal-url="/ajax/forms/enter.php" class="header-enter header-button--flex">
                        <svg class="header-enter__icon header-button_icon">
                            <use href="assets/img/svg-icons.svg#enter"></use>
                        </svg>
                        <span>Войти</span>
                    </a>
                    <a href="#" class="header-basket header-button--flex">
                        <svg class="header-basket__icon header-button_icon">
                            <use href="assets/img/svg-icons.svg#basket"></use>
                        </svg>
                        <span class="header-basket__label" id="header-basket">7</span>
                        <span>Корзина</span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="header-helper"></div>
?>





















<?echo "2";?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Сибирский дом техники</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Exo:wght@400;500&display=swap" rel="stylesheet">

    <link href="assets/css/animation.min.css" rel="stylesheet">
    <link href="assets/css/normalize.min.css" rel="stylesheet">
    <link href="assets/plugins/tinyslider/tiny-slider.min.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">

    <script src="assets/plugins/tinyslider/tiny-slider.min.js"></script>
    <script src="assets/js/tabs.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/catalog.min.js"></script>
</head>
<body id="body">

<div class="wrapper">

    <header class="header is-not-main" id="header">
        <div class="header-top">
            <div class="container">
                <div class="header-top-left mb--hidden">
                    <div class="header-social">
                        <ul class="header-social-list">
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--facebook">
                                        <use href="assets/img/svg-icons.svg#facebook"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--twitter">
                                        <use href="assets/img/svg-icons.svg#twitter"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--youtube">
                                        <use href="assets/img/svg-icons.svg#youtube"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--insta">
                                        <use href="assets/img/svg-icons.svg#instagram"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--telegram">
                                        <use href="assets/img/svg-icons.svg#telegram"></use>
                                    </svg>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <a href="#" target="_blank" class="header-slogan">Наши товары на маркетплейсах</a>
                </div>
                <a href="javascript:void(0);" class="header-mobile-burger header-catalog-burger mb--visible">
                    <i></i>
                </a>
                <div class="header-top-right">
                    <div class="header-menu mb--hidden">
                        <ul class="header-menu-list">
                            <li class="header-menu_item"><a class="header-menu_link" href="#">Акции</a></li>
                            <li class="header-menu_item"><a class="header-menu_link" href="#">Бренды</a></li>
                            <li class="header-menu_item"><a class="header-menu_link" href="#">Доставка и оплата</a></li>
                            <li class="header-menu_item">
                                <a class="header-menu_link has--child" href="#">
                                    Сервис
                                    <svg class="arrow-down_icon">
                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                    </svg>
                                </a>
                                <div class="menu-child">
                                    <ul class="menu-child-list">
                                        <li class="menu-child_item"><a href="#">Сервисные центры</a></li>
                                        <li class="menu-child_item"><a href="#">Правила гарантийного обслуживания</a></li>
                                    </ul>
                                </div>

                            </li>
                            <li class="header-menu_item">
                                <a class="header-menu_link has--child" href="#">
                                    О компании
                                    <svg class="arrow-down_icon">
                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                    </svg>
                                </a>
                                <div class="menu-child">
                                    <ul class="menu-child-list">
                                        <li class="menu-child_item"><a href="#">О компании</a></li>
                                        <li class="menu-child_item"><a href="#">Документы</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li class="header-menu_item"><a class="header-menu_link" href="#">Контакты</a></li>
                        </ul>
                    </div>
                    <a class="header-phone" href="tel:+73832119683">
                        <svg class="header-phone_icon">
                            <use href="assets/img/svg-icons.svg#header-phone"></use>
                        </svg>
                        +7 (383) 211 96 83
                    </a>
                </div>
            </div>
        </div>
        <div class="header-bottom">
            <div class="container">
                <a class="header-logo logo--big" href="/"><img src="assets/img/logo.svg" alt=""></a>
                <a class="header-logo logo--small" href="/"><img src="assets/img/logo-small.svg" alt=""></a>
                <a href="javascript:void(0);" class="header-catalog-btn button mb--hidden">
                        <span class="header-catalog-burger">
                            <i></i>
                        </span>
                    <span>Каталог</span>
                </a>
                <div class="header-menu is-scroll-visible mb--hidden">
                    <ul class="header-menu-list">
                        <li class="header-menu_item"><a class="header-menu_link" href="#">Акции</a></li>
                        <li class="header-menu_item"><a class="header-menu_link" href="#">Бренды</a></li>
                        <li class="header-menu_item"><a class="header-menu_link" href="#">Доставка и оплата</a></li>
                        <li class="header-menu_item">
                            <a class="header-menu_link has--child" href="#">
                                Сервис
                                <svg class="arrow-down_icon">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                            <div class="menu-child">
                                <ul class="menu-child-list">
                                    <li class="menu-child_item"><a href="#">Сервисные центры</a></li>
                                    <li class="menu-child_item"><a href="#">Правила гарантийного обслуживания</a></li>
                                </ul>
                            </div>

                        </li>
                        <li class="header-menu_item">
                            <a class="header-menu_link has--child" href="#">
                                О компании
                                <svg class="arrow-down_icon">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                            <div class="menu-child">
                                <ul class="menu-child-list">
                                    <li class="menu-child_item"><a href="#">О компании</a></li>
                                    <li class="menu-child_item"><a href="#">Документы</a></li>
                                </ul>
                            </div>
                        </li>
                        <li class="header-menu_item"><a class="header-menu_link" href="#">Контакты</a></li>
                    </ul>
                </div>
                <div class="header-catalog">
                    <div class="index-catalog-list">
                        <div class="index-catalog-item catalog-img mb--visible">
                            <a href="#" class="catalog-img_link">
                                <img src="assets\img\Sakura-logo.svg" alt="">
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link has--menu">
                                Телевизоры, аудио, видео
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                            <div class="index-catalog-submenu">
                                <div class="catalog-submenu__inner">
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Крупная бытовая техника</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Вытяжки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Духовки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Холодильники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посудомоечные машины
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Винные шкафы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Мелкая бытовая техника</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Аэрогрили
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Блендеры
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Блинницы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Вафельницы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Мясорубки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Посуда и аксессуары</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для приготовления
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Аксессуары для готовки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Казаны
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Кастрюли
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Крышки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Мантоварки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Наборы посуды
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Ножи
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для духовки и СВЧ
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Разделочные доски
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сковороды
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Формы для выпечки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Сервировка</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Графины
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Заварники и кофейники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Наборы для специй
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сахарницы и масленки</a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Кружки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для детей
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Салатники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сервизы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Столовые приборы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Tарелки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Фужеры и бокалы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Подносы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link has--menu">
                                Инструменты
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                            <div class="index-catalog-submenu">
                                <div class="catalog-submenu__inner">
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Крупная бытовая техника</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Вытяжки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Духовки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Холодильники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посудомоечные машины
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Винные шкафы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Мелкая бытовая техника</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Аэрогрили
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Блендеры
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Блинницы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Вафельницы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Мясорубки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Посуда и аксессуары</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для приготовления
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Аксессуары для готовки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Казаны
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Кастрюли
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Крышки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Мантоварки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Наборы посуды
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Ножи
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для духовки и СВЧ
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Разделочные доски
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сковороды
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Формы для выпечки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="catalog-submenu-list">
                                        <div class="catalog-submenu__subtitle">
                                            <a href="#">Сервировка</a>
                                        </div>
                                        <div class="catalog-submenu__list">
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Графины
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Заварники и кофейники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Наборы для специй
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сахарницы и масленки</a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Кружки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Посуда для детей
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Салатники
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Сервизы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Столовые приборы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Tарелки
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Фужеры и бокалы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="catalog-submenu__item">
                                                <a href="#">
                                                    Подносы
                                                    <svg class="mb--visible arrow-down">
                                                        <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Красота и здоровье
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Товары для авто
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Дача и сад
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Текстиль
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Товары для дома и кухни
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Техника для дома
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Техника для кухни
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link">
                                Программное обеспечение
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="index-catalog-item">
                            <a href="#" class="catalog-menu__link is-red">
                                %Распродажа
                                <svg class="mb--visible arrow-down">
                                    <use href="assets/img/svg-icons.svg#arrow-down"></use>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="header-search">
                    <form class="search-form">
                        <input type="search" class="search-input" id="search-input" placeholder="Искать товары">
                        <button class="search-button">
                            <svg>
                                <use href="assets/img/svg-icons.svg#search-btn"></use>
                            </svg>
                        </button>
                        <a href="javascript:void(0);" class="is-scroll-visible search__icon">
                            <svg>
                                <use href="assets/img/svg-icons.svg#search-btn"></use>
                            </svg>
                        </a>
                    </form>
                </div>
                <div class="header-button-list">
                    <a href="#" class="header-compare header-button--flex">
                        <svg class="header-compare__icon header-button_icon">
                            <use href="assets/img/svg-icons.svg#compare"></use>
                        </svg>
                        <span>Сравнение</span>
                    </a>
                    <a href="#" class="header-favorite header-button--flex">
                        <svg class="header-favorite__icon header-button_icon">
                            <use href="assets/img/svg-icons.svg#favorite"></use>
                        </svg>
                        <span class="header-favorite__label" id="header-favorite">125</span>
                        <span>Избранное</span>
                    </a>
                    <a href="#" data-modal-target="enter" data-modal-url="/ajax/forms/enter.php" class="header-enter header-button--flex">
                        <svg class="header-enter__icon header-button_icon">
                            <use href="assets/img/svg-icons.svg#enter"></use>
                        </svg>
                        <span>Войти</span>
                    </a>
                    <a href="#" class="header-basket header-button--flex">
                        <svg class="header-basket__icon header-button_icon">
                            <use href="assets/img/svg-icons.svg#basket"></use>
                        </svg>
                        <span class="header-basket__label" id="header-basket">7</span>
                        <span>Корзина</span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="header-helper"></div>








<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?if (!empty($arResult)):?>

<div class="menu-sitemap-tree">
<ul>
<?
$previousLevel = 0;
foreach($arResult as $arItem):
?>
	<?if ($previousLevel && $arItem["DEPTH_LEVEL"] < $previousLevel):?>
		<?=str_repeat("</ul></li>", ($previousLevel - $arItem["DEPTH_LEVEL"]));?>
	<?endif?>

	<?if ($arItem["IS_PARENT"]):?>
			<li<?if($arItem["CHILD_SELECTED"] !== true):?> class="menu-close"<?endif?>>
				<div class="folder" onClick="OpenMenuNode(this)"></div>
				<div class="item-text"><a href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?></a></div>
				<ul>

	<?else:?>

		<?if ($arItem["PERMISSION"] > "D"):?>
				<li>
					<div class="page"></div>
					<div class="item-text"><a href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?></a></div>
				</li>
		<?endif?>

	<?endif?>

	<?$previousLevel = $arItem["DEPTH_LEVEL"];?>

<?endforeach?>

<?if ($previousLevel > 1)://close last item tags?>
	<?=str_repeat("</ul></li>", ($previousLevel-1) );?>
<?endif?>

</ul>
</div>
<?endif?>







<?if (!empty($arResult)):?>
<ul class="left-menu">

<?
foreach($arResult as $arItem):
	if($arParams["MAX_LEVEL"] == 1 && $arItem["DEPTH_LEVEL"] > 1) 
		continue;
?>
	<?if($arItem["SELECTED"]):?>
		<li><a href="<?=$arItem["LINK"]?>" class="selected"><?=$arItem["TEXT"]?></a></li>
	<?else:?>
		<li><a href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?></a></li>
	<?endif?>
	
<?endforeach?>

</ul>
<?endif?>






















<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

$res = CIBlockElement::GetProperty(13, 345);
while ($row = $res->Fetch())
	{$path_logo = $row['VALUE'];}
?>
<div class="index-catalog-list">
	<div class="index-catalog-item catalog-img">
        <a href="#"><img src="<?echo $path_logo?>" alt=""></a>
    </div>

<?foreach($arResult["ITEMS"] as $arItem):?>
	<?
	
	//var_dump($arItem);
	
	
	$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
	$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
	?>
	<div class="index-catalog-item" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
		<?if($arParams["DISPLAY_NAME"]!="N" && $arItem["NAME"]):?>
				<?if ($arItem["NAME"] == "%Распродажа") :?>
					<a href="<?echo $arItem["LINK"]?>" class="catalog-menu__link is-red"><?echo $arItem["NAME"]?></a>
					<?else:?>
					<?if ($arItem["IBLOCK_SECTION_ID"]!=NULL) :?>
					<a href="<?echo $arItem["LINK"]?>" class="catalog-menu__link"><?echo $arItem["NAME"]?>f</a>
						<?$res = CIBlockSection::GetByID($arItem["IBLOCK_SECTION_ID"]);
					if($ar_res = $res->GetNext())
					var_dump ($ar_res['NAME']);?>
					<?else:?>
					<a href="<?echo $arItem["LINK"]?>" class="catalog-menu__link"><?echo $arItem["NAME"]?>fff</a>
					<?endif;?>
			<?endif;?>		
		<?endif;?>		
	</div>
	

	
<?endforeach;?>
</div>








		case 'LIST':
			$endDiv = NULL;

				$res = CIBlockElement::GetProperty(13, 345);
				while ($row = $res->Fetch())
					{$path_logo = $row['VALUE'];}
				?>
				<div class="index-catalog-list">
					<div class="index-catalog-item catalog-img">
						<a href="#"><img src="<?echo $path_logo?>" alt=""></a>
					</div>
				<?

			foreach ($arResult['SECTIONS'] as &$arSection)
			{
				$this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], $strSectionEdit);
				$this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);

				if ($arSection['DEPTH_LEVEL']==1){
				?><div class="index-catalog-item">
					<a href="#" class="catalog-menu__link"><?echo $arSection['NAME']?></a>
						<div class="index-catalog-submenu">
                            <div class="catalog-submenu__inner">
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#">Крупная бытовая техника</a>
                                    </div>
                                    <div class="catalog-submenu__list">
                                        <div class="catalog-submenu__item">
                                            <a href="#">Вытяжки</a>
                                        </div>
                                    </div></div></div></div></div>
				<?}
				$arSelect = Array("ID", "NAME", "IBLOCK_SECTION_ID");
				$arFilter = array("IBLOCK_ID"=> 16);
				$res = CIBlockElement::GetList(Array(), $arFilter, false, false);
				 while($ob = $res->GetNextElement())
				{
				  $arFields = $ob->GetFields();
				  //var_dump($arFields);
				  if ($arFields['DEPTH_LEVEL'] == NULL){
					echo $arFields['NAME'];
				  }
				  //$arRes['ITEMS'] = $arFields;
				}
			}?></div><?
			//unset($arSection);
























    case 'LIST':
        $endDiv = NULL;

        $res = CIBlockElement::GetProperty(13, 345);
        while ($row = $res->Fetch()) {
            $path_logo = $row['VALUE'];
        }
        ?>
        <div class="index-catalog-list">
        <div class="index-catalog-item catalog-img">
            <a href="#"><img src="<? echo $path_logo ?>" alt=""></a>
        </div>
        <?
        $check = 0;
        $check2 = 0;
        foreach ($arResult['SECTIONS'] as &$arSection) {
            $this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], $strSectionEdit);
            $this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);

            if ($arSection['DEPTH_LEVEL'] == 1) {
                if ($check == 1) {
                    ?></div><? ?></div><? ?></div><? $check = 0;
                }
                ?><div class="index-catalog-item">
                <a href="#" class="catalog-menu__link"><? echo $arSection['NAME'] ?></a>
                <div class="index-catalog-submenu">
                <div class="catalog-submenu__inner">
                <? $check = 0;
            } elseif ($arSection['DEPTH_LEVEL'] == 2) {
                ?>
                <div class="catalog-submenu-list">
                    <div class="catalog-submenu__subtitle">
                        <a href="#"><? echo $arSection['NAME'] ?></a>
                        <? $check2 = $arSection['ID'];?>
                    </div>
                    <div class="catalog-submenu__list">
                        <?
                        $arSelect = array("ID", "NAME", "IBLOCK_SECTION_ID");
                        $arFilter = array("IBLOCK_ID" => 16);
                        $res = CIBlockElement::GetList(array(), $arFilter, false, false);
                        while ($ob = $res->GetNextElement()) {
                            $arFields = $ob->GetFields();
                            if (($arFields['IBLOCK_SECTION_ID'] == $check2) && ($arFields['IBLOCK_SECTION_ID'] != NULL)) {
                                ?>
                                <div class="catalog-submenu__item">
                                <a href="#"><? echo $arFields['NAME']; ?></a>
                                </div><?
                            }
                        }
                        ?>
                    </div>
                </div>
                <?
            }
            $check = 1;
        }

    if ($check == 1) {
        ?>
        </div><? $check = 0;
    }
        ?></div><? ?></div><?
        $arSelect = array("ID", "NAME", "IBLOCK_SECTION_ID");
        $arFilter = array("IBLOCK_ID" => 16);
        $res = CIBlockElement::GetList(array(), $arFilter, false, false);
        while ($ob = $res->GetNextElement()) {
            $arFields = $ob->GetFields();
            if ($arFields['IBLOCK_SECTION_ID'] == NULL) {
                ?>
                <div class="index-catalog-item">
                <div class="catalog-menu__link">
                    <? if ($arFields["NAME"] == "%Распродажа") { ?>
                        <a href="<? echo $arFields["LINK"] ?>"
                           class="catalog-menu__link is-red"><? echo $arFields["NAME"] ?></a>
                    <? } else { ?>
                        <a href="<? echo $arFields["LINK"] ?>"><? echo $arFields['NAME']; ?></a>
                    <?
                    } ?>
                </div></div><?
            }
        }
        ?></div><?
        unset($arSection, $res, $arFilter, $arFields, $arResult, $check, $check2, $ob, $path_logo);
        break;





























                //
case 'LIST':
    $intCurrentDepth = 1;
    $boolFirst = true;
    $check = false;
foreach ($arResult['SECTIONS'] as &$arSection)
{
    $this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], $strSectionEdit);
    $this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);

    if ($intCurrentDepth < $arSection['RELATIVE_DEPTH_LEVEL'])
    {
        if (0 < $intCurrentDepth){
            if ($arSection['RELATIVE_DEPTH_LEVEL']==2){
            echo "\n",str_repeat("\t", $arSection['RELATIVE_DEPTH_LEVEL']),'<div class="index-catalog-submenu"><div  class="catalog-submenu__inner">';}}
    }
    elseif ($intCurrentDepth == $arSection['RELATIVE_DEPTH_LEVEL'])
    {
        if (!$boolFirst)
            echo '</div>';
    }
    else
    {
        while ($intCurrentDepth > $arSection['RELATIVE_DEPTH_LEVEL'])
        {
            echo '</div>',"\n",str_repeat("\t", $intCurrentDepth),'</div>',"\n",str_repeat("\t", $intCurrentDepth-1);
            $intCurrentDepth--;
        }
        echo str_repeat("\t", $intCurrentDepth-1),'</div>';
    }

    echo (!$boolFirst ? "\n" : ''),str_repeat("\t", $arSection['RELATIVE_DEPTH_LEVEL']);

    if ($arSection['RELATIVE_DEPTH_LEVEL'] == 1) {
        if ($check == true){echo '</div>'; $check = false;}?>
        <div class="index-catalog-item"><a class="catalog-menu__link" href="#"><? echo $arSection["NAME"]; ?></a><?

    } elseif ($arSection['RELATIVE_DEPTH_LEVEL'] == 2) {
    $check = true;?>
        <div class="catalog-submenu-list">
        <div class="catalog-submenu__subtitle">
            <a href="#"><? echo $arSection["NAME"]; ?></a>
        </div>

        <?
    } elseif ($arSection['RELATIVE_DEPTH_LEVEL'] == 3) {
        if ($intCurrentDepth < $arSection['RELATIVE_DEPTH_LEVEL']){echo '<div class="catalog-submenu__list">';}
        ?>
        <div class="catalog-submenu__item">
        <a href="#"><? echo $arSection["NAME"]; ?></a>
        <?}

    $intCurrentDepth = $arSection['RELATIVE_DEPTH_LEVEL'];
    $boolFirst = false;
}
    unset($arSection);
    while ($intCurrentDepth > 1)
    {
        echo '</div>',"\n",str_repeat("\t", $intCurrentDepth),'</div>',"\n",str_repeat("\t", $intCurrentDepth-1);
        $intCurrentDepth--;
    }
    if ($intCurrentDepth > 0)
    {
        echo '</div>',"\n";
    }
    if ($check == true){echo '</div>'; $check = false;}
    break;
    //
}
?>
    </div>
    <a>111</a>
<?
?>

//
<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

$arViewModeList = $arResult['VIEW_MODE_LIST'];

$arViewStyles = array(
    'LIST' => array(
        'CONT' => 'bx_sitemap',
        'TITLE' => 'bx_sitemap_title',
        'LIST' => 'bx_sitemap_ul',
    ),
    'LINE' => array(
        'CONT' => 'bx_catalog_line',
        'TITLE' => 'bx_catalog_line_category_title',
        'LIST' => 'bx_catalog_line_ul',
        'EMPTY_IMG' => $this->GetFolder() . '/images/line-empty.png'
    ),
    'TEXT' => array(
        'CONT' => 'bx_catalog_text',
        'TITLE' => 'bx_catalog_text_category_title',
        'LIST' => 'bx_catalog_text_ul'
    ),
    'TILE' => array(
        'CONT' => 'bx_catalog_tile',
        'TITLE' => 'bx_catalog_tile_category_title',
        'LIST' => 'bx_catalog_tile_ul',
        'EMPTY_IMG' => $this->GetFolder() . '/images/tile-empty.png'
    )
);
$arCurView = $arViewStyles[$arParams['VIEW_MODE']];

$strSectionEdit = CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "SECTION_EDIT");
$strSectionDelete = CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "SECTION_DELETE");
$arSectionDeleteParams = array("CONFIRM" => GetMessage('CT_BCSL_ELEMENT_DELETE_CONFIRM'));

$this->AddEditAction($arResult['SECTION']['ID'], $arResult['SECTION']['EDIT_LINK'], $strSectionEdit);
$this->AddDeleteAction($arResult['SECTION']['ID'], $arResult['SECTION']['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);
$res = CIBlockElement::GetProperty(13, 345);
while ($row = $res->Fetch()) {
    $arResult['PATH_LOGO'] = $row['VALUE'];
}
?><div class="index-catalog-list">
    <div class="index-catalog-item catalog-img">
    <a href="#"><img src="<? echo $arResult['PATH_LOGO'] ?>" alt=""></a>
    </div><?
switch ($arParams['VIEW_MODE']) {
    case 'LINE':
        foreach ($arResult['SECTIONS'] as &$arSection) {
            $this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], $strSectionEdit);
            $this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);

            if (false === $arSection['PICTURE'])
                $arSection['PICTURE'] = array(
                    'SRC' => $arCurView['EMPTY_IMG'],
                    'ALT' => (
                    '' != $arSection["IPROPERTY_VALUES"]["SECTION_PICTURE_FILE_ALT"]
                        ? $arSection["IPROPERTY_VALUES"]["SECTION_PICTURE_FILE_ALT"]
                        : $arSection["NAME"]
                    ),
                    'TITLE' => (
                    '' != $arSection["IPROPERTY_VALUES"]["SECTION_PICTURE_FILE_TITLE"]
                        ? $arSection["IPROPERTY_VALUES"]["SECTION_PICTURE_FILE_TITLE"]
                        : $arSection["NAME"]
                    )
                );
            ?>
        <li id="<? echo $this->GetEditAreaId($arSection['ID']); ?>">
            <a
                    href="<? echo $arSection['SECTION_PAGE_URL']; ?>"
                    class="bx_catalog_line_img"
                    style="background-image: url('<? echo $arSection['PICTURE']['SRC']; ?>');"
                    title="<? echo $arSection['PICTURE']['TITLE']; ?>"
            ></a>
            <h2 class="bx_catalog_line_title"><a
                        href="<? echo $arSection['SECTION_PAGE_URL']; ?>"><? echo $arSection['NAME']; ?></a><?
                if ($arParams["COUNT_ELEMENTS"] && $arSection['ELEMENT_CNT'] !== null) {
                    ?> <span>(<? echo $arSection['ELEMENT_CNT']; ?>)</span><?
                }
                ?></h2><?
            if ('' != $arSection['DESCRIPTION']) {
                ?><p class="bx_catalog_line_description"><? echo $arSection['DESCRIPTION']; ?></p><?
            }
            ?>
            <div style="clear: both;"></div>
            </li><?
        }
        unset($arSection);
        break;
    case 'TEXT':
        foreach ($arResult['SECTIONS'] as &$arSection) {
            $this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], $strSectionEdit);
            $this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);

            ?>
        <li id="<? echo $this->GetEditAreaId($arSection['ID']); ?>"><h2 class="bx_catalog_text_title"><a
                        href="<? echo $arSection['SECTION_PAGE_URL']; ?>"><? echo $arSection['NAME']; ?></a><?
                if ($arParams["COUNT_ELEMENTS"] && $arSection['ELEMENT_CNT'] !== null) {
                    ?> <span>(<? echo $arSection['ELEMENT_CNT']; ?>)</span><?
                }
                ?></h2></li><?
        }
        unset($arSection);
        break;
    case 'TILE':
        foreach ($arResult['SECTIONS'] as &$arSection) {
            $this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], $strSectionEdit);
            $this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);

            if (false === $arSection['PICTURE'])
                $arSection['PICTURE'] = array(
                    'SRC' => $arCurView['EMPTY_IMG'],
                    'ALT' => (
                    '' != $arSection["IPROPERTY_VALUES"]["SECTION_PICTURE_FILE_ALT"]
                        ? $arSection["IPROPERTY_VALUES"]["SECTION_PICTURE_FILE_ALT"]
                        : $arSection["NAME"]
                    ),
                    'TITLE' => (
                    '' != $arSection["IPROPERTY_VALUES"]["SECTION_PICTURE_FILE_TITLE"]
                        ? $arSection["IPROPERTY_VALUES"]["SECTION_PICTURE_FILE_TITLE"]
                        : $arSection["NAME"]
                    )
                );
            ?>
        <li id="<? echo $this->GetEditAreaId($arSection['ID']); ?>">
        <a
                href="<? echo $arSection['SECTION_PAGE_URL']; ?>"
                class="bx_catalog_tile_img"
                style="background-image:url('<? echo $arSection['PICTURE']['SRC']; ?>');"
                title="<? echo $arSection['PICTURE']['TITLE']; ?>"
        > </a><?
            if ('Y' != $arParams['HIDE_SECTION_NAME']) {
                ?><h2 class="bx_catalog_tile_title"><a
                href="<? echo $arSection['SECTION_PAGE_URL']; ?>"><? echo $arSection['NAME']; ?></a><?
                if ($arParams["COUNT_ELEMENTS"] && $arSection['ELEMENT_CNT'] !== null) {
                    ?> <span>(<? echo $arSection['ELEMENT_CNT']; ?>)</span><?
                }
                ?></h2><?
            }
            ?></li><?
        }
        unset($arSection);
        break;

    //
case 'LIST':
    //var_dump($arResult);
    $intCurrentDepth = 1;
    $boolFirst = true;
    $check = false;
    $endTag1 = false;
    $endTag2 = false;
    $endTag3 = false;

//    echo '<pre>';
//    var_dump($arResult['SECTIONS']);
//    echo '</pre>';

foreach ($arResult['SECTIONS'] as &$arSection)
{


    $this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], $strSectionEdit);
    $this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);

    if ($arSection['RELATIVE_DEPTH_LEVEL'] == 1) {
    if ($endTag1==true){echo "</div>";$endTag1=false;}
    if ($endTag2==true){echo "</div></div>";$endTag2=false;}
    if ($endTag3==true){echo "</div></div>";$endTag3=false;}

        if ($arSection["NAME"]=="%Распродажа"){?>
        <div class="index-catalog-item"><a class="catalog-menu__link is-red" href="#"><? echo $arSection["NAME"]; ?></a></div><?
        } else {?>
        <div class="index-catalog-item"><a class="catalog-menu__link" href="#"><? echo $arSection["NAME"]; ?></a><? $endTag1=true; }

    } elseif ($arSection['RELATIVE_DEPTH_LEVEL'] == 2) {
    if ($intCurrentDepth < $arSection['RELATIVE_DEPTH_LEVEL']){echo '<div class="index-catalog-submenu"><div  class="catalog-submenu__inner">';}
        if ($endTag2==true){echo "</div></div>";$endTag2=false;}
    $endTag2 = true;?>
        <div class="catalog-submenu-list">
        <div class="catalog-submenu__subtitle">
            <a href="#"><? echo $arSection["NAME"]; ?></a>
        </div>

        <?
    } elseif ($arSection['RELATIVE_DEPTH_LEVEL'] == 3) {
        if ($intCurrentDepth < $arSection['RELATIVE_DEPTH_LEVEL']){echo '<div class="catalog-submenu__list">';}
        $endTag3 = true;?>
        <div class="catalog-submenu__item">
        <a href="#"><? echo $arSection["NAME"]; ?></a>
        </div>
        <?}

    $intCurrentDepth = $arSection['RELATIVE_DEPTH_LEVEL'];
    $boolFirst = false;
}
    unset($arSection);

    //
    break;
}
?>

            <?if ($endTag1==true){echo "</div>";$endTag1=false;}
            if ($endTag2==true){echo "</div></div></div>";$endTag2=false;}
    if ($endTag3==true){echo "</div></div>";$endTag3=false;}?>
    </div>
<!--    <div><a>Проверка изменений</a></div>-->
<?
?>