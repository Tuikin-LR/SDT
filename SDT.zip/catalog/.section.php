<?
$sSectionName = "Каталог";
$arDirProperties = Array(
   "description" => "J",
   "keywords" => "n"
);
?>