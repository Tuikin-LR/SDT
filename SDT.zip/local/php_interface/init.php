<?php
define("IB_siteSettings", 6);
define("IB_promotionalLinks", 7);
define("IB_mainSlider", 9);
define("IB_catalog", 11);
define("IB_special_offers", 12);
define("IB_stocks", 13);

global $siteSettings;

$CACHE_TIME = 86400;
$CACHE_ID = "some_key_iblock"; //.implode('_', $siteSettings);
$obCache = new CPHPCache;

if ($obCache->InitCache($CACHE_TIME, $CACHE_ID, "/")) {
    $siteSettings = $obCache->GetVars();
} else {
    if ($obCache->StartDataCache()):

        if (CModule::IncludeModule("iblock")):
            $arSort = array('SORT' => 'DESC');
            $arFilter = array('ACTIVE' => 'Y', 'IBLOCK_ID' => IB_siteSettings);
            $arSelect = array('ID',
                'IBLOCK_ID', 'NAME', 'PROPERTY_PATH_LOGO', 'PROPERTY_PATH_LOGO_SMALL',
                'PROPERTY_PATH_LOGO_FOOTER', 'PROPERTY_PATH_LOGO_SAKURA',
                'PROPERTY_PATH_LOGO_VISA', 'PROPERTY_PATH_LOGO_MAESTRO',
                'PROPERTY_PATH_LOGO_MASTER', 'PROPERTY_NUMBER', 'PROPERTY_PATH_IMG_PHONE'
            );

            $res = CIBlockElement::getList($arSort, $arFilter, false, array("nTopCount" => 1), $arSelect);
            while ($row = $res->fetch()) {
                $siteSettings = array(
                    'PATH_LOGO' => $row['PROPERTY_PATH_LOGO_VALUE'],
                    'PATH_LOGO_SMALL' => $row['PROPERTY_PATH_LOGO_SMALL_VALUE'],
                    'PATH_LOGO_FOOTER' => $row['PROPERTY_PATH_LOGO_FOOTER_VALUE'],
                    'PATH_LOGO_SAKURA' => $row['PROPERTY_PATH_LOGO_SAKURA_VALUE'],
                    'PATH_LOGO_VISA' => $row['PROPERTY_PATH_LOGO_VISA_VALUE'],
                    'PATH_LOGO_MAESTRO' => $row['PROPERTY_PATH_LOGO_MAESTRO_VALUE'],
                    'PATH_LOGO_MASTER' => $row['PROPERTY_PATH_LOGO_MASTER_VALUE'],
                    'NUMBER' => $row['PROPERTY_NUMBER_VALUE'],
                    'PATH_IMG_PHONE' => $row['PROPERTY_PATH_IMG_PHONE_VALUE'],
                );
            }
            $obCache->EndDataCache($siteSettings);
        endif;
    endif;
}


$pageUrl = $APPLICATION->GetCurPage();

if ($pageUrl === '/') {
    $isIndex = true;
} elseif (substr_count($pageUrl, '/test.php') === 1) {
    $isTest = true;
} elseif ($pageUrl === '/catalog/') {
    $isCatalog = true;
}


global $test_siteMarker;
$test_siteMarker = $_SERVER["DOCUMENT_ROOT"] . '/test.php';
global $main_siteMarker;
$main_siteMarker = $_SERVER["DOCUMENT_ROOT"] . '/index.php';

if (!function_exists('array_key_last')) {
    function array_key_last(array $array)
    {
        if (!empty($array)) return key(array_slice($array, -1, 1, true));
    }
}

function catalogItem($arr, $cntSections, $i, $arr2)
{
    if (isset($arr2['DEPTH_LEVEL'])) {

        if ($arr[$i]['DEPTH_LEVEL'] == 1) {
            $arr2[$i] = $arr[$i];
            $arr2[$i]['PARENT'] = "null";
            unset($arr2['PARENT']);

        } elseif ($arr[$i]['DEPTH_LEVEL'] == $arr2['DEPTH_LEVEL']) {
            $arr2[$i] = $arr[$i];
            $arr2[$i]['PARENT'] = explode(",", implode(",", $arr2['PARENT']));

        } elseif ($arr[$i]['DEPTH_LEVEL'] > $arr2['DEPTH_LEVEL']) {
            $arr2['PARENT'][] = $i - 1;
            $arr2[$i] = $arr[$i];
            $arr2[$i]['PARENT'] = explode(",", implode(",", $arr2['PARENT']));

        } elseif ($arr[$i]['DEPTH_LEVEL'] < $arr2['DEPTH_LEVEL']) {
            while ($d < ($arr2['DEPTH_LEVEL'] - $arr[$i]['DEPTH_LEVEL'])) {
                unset($arr2['PARENT'][array_key_last($arr2['PARENT'])]);
                $d++;
            }
            $arr2[$i] = $arr[$i];
            $arr2[$i]['PARENT'] = explode(",", implode(",", $arr2['PARENT']));

        }
    } else {
        if ($arr[$i]['DEPTH_LEVEL'] == 1) {
            $arr2[$i] = $arr[$i];
            $arr2[$i]['PARENT'] = "null";

        }
    }

    $arr2['DEPTH_LEVEL'] = $arr[$i]['DEPTH_LEVEL'];

    if ($i >= $cntSections) {  // base case
        unset($arr2['DEPTH_LEVEL']);
        return catalogSort($arr2, $cntSections);
    } else {       // recursive case
        return catalogItem($arr, $cntSections, $i + 1, $arr2);
    }
}

function catalogSort($arr, $cntSections)
{
    if ($arr[$cntSections]['PARENT'] != 'null') {
        $arr[$arr[$cntSections]['PARENT'][array_key_last($arr[$cntSections]['PARENT'])]]['SUBMENU'][] = array();
        unset($arr[$arr[$cntSections]['PARENT'][array_key_last($arr[$cntSections]['PARENT'])]]['SUBMENU'][array_key_last($arr[$arr[$cntSections]['PARENT'][array_key_last($arr[$cntSections]['PARENT'])]]['SUBMENU'])]);

        $parent = $arr[$cntSections]['PARENT'][array_key_last($arr[$cntSections]['PARENT'])];
        unset($arr[$cntSections]['PARENT']);

        array_unshift($arr[$parent]['SUBMENU'], $arr[$cntSections]);
        unset($arr[$cntSections]);

    } else {
        unset($arr[$cntSections]['PARENT']);
    }

    if ($cntSections <= 0) {  // base case
//        var_dump($arr['SECTIONS']);
        return $arr;
    } else {       // recursive case
        return catalogSort($arr, $cntSections - 1);
    }

}
?>