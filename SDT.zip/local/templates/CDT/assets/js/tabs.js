var Tabs = (function() {
    var clearTabs = function(dom) {
        if (!dom) return false;
        var i, l;
        if (dom.targets.length) {
            for (i = 0, l = dom.targets.length; i < l; i++) {
                dom.targets[i].classList.remove('is-active');
            }
        }
        if (dom.contents.length) {
            for (i = 0, l = dom.contents.length; i < l; i++) {
                dom.contents[i].classList.remove('is-active');
            }
        }
    };

    var openTab = function(event) {
        event.preventDefault();
        var target = this;

        if (target.classList.contains('is-active') || !target.dom) {
            return false;
        }

        clearTabs(target.dom);

        var curContent;

        for (var i = 0, l = target.dom.contents.length; i < l; i++) {
            if (target.dom.contents[i].dataset.tabsId && target.dataset.tabsTarget &&  target.dom.contents[i].dataset.tabsId === target.dataset.tabsTarget) {
                curContent = target.dom.contents[i];
            }
        }

        if (curContent) {
            curContent.classList.add('is-active');
        }

        target.classList.add('is-active');
    };

    var initTabsBlock = function(wrap) {
        var targets = wrap.querySelectorAll('[data-tabs-target]');
        var contents = wrap.querySelectorAll('[data-tabs-id]');

        if (targets.length) {
            for (var i = 0, l = targets.length; i < l; i++) {
                targets[i].dom = {
                    wrap: wrap,
                    targets: targets,
                    contents: contents
                };

                targets[i].addEventListener('click', openTab);
            }
        }
    };

    var init = function() {
        var wrappers = document.querySelectorAll('[data-tabs]');

        if (wrappers.length) {
            for (var i = 0, l = wrappers.length; i < l; i++) {
                initTabsBlock(wrappers[i]);
            }
        }
    };

    window.addEventListener('DOMContentLoaded', init);
})();