BX.namespace('BX.Catalog');
BX.namespace('BX.CardCarousel');

(function () {
    'use strict';

    BX.Catalog = {
        containerID: 'body',
        basketID: 'header-basket',
        favoriteID: 'header-favorite',

        mainUrl: '/ajax/fp.php',

        init: function () {
            this.container = BX(this.containerID);

            if (!this.container) return false;


            BX.bindDelegate(this.container, 'click', {attribute: 'data-catalog'}, BX.delegate(this.setAction, this));
            this.removeInsertLinks();
        },

        removeInsertLinks: function () {
            let items = BX.findChild(document.body, {attribute: {'data-component': 'item'}}, true, true);
            if (items.length) {
                for (let i = 0, l = items.length; i < l; i++) {
                    let links = BX.findChild(items[i], {tag: 'a'}, true, true);
                    if (links.length) {
                        for (let j = 0, jl = links.length; j < jl; j++) {
                            links[j].onclick = '';
                            links[j].removeAttribute('onclick');
                        }
                    }
                }
            }
        },

        setAction: function (e) {
            BX.PreventDefault(e);
            let target = BX.proxy_context;
            let params = target.dataset.catalog;
            if (params) {
                params = JSON.parse(params.replace(/\s/g, '').replace(/\'/g, '\"'));
                let action = params.action ? params.action : null;

                switch (action) {
                    case 'favorite':
                        this.toggleFavorite(target, params);
                        break;
                    case 'compare':
                        this.toggleCompare(target, params);
                        break;
                    case 'addBasket':
                        this.addBasket(target, params);
                        break;
                }
            }
        },

        checkAllItemFavorite: function (params, status) {
            let items = document.querySelectorAll('[data-catalog*="favorite"][data-catalog*="' + params.id + '"]');
            if (items.length) {
                for (let i = 0, l = items.length; i < l; i++) {
                    if (status === "ADD") {
                        items[i].classList.add('is-checked');
                    } else {
                        items[i].classList.remove('is-checked');
                    }
                }
            }
        },

        setFavoriteFromArray: function (arr) {
            if (typeof arr === 'string') arr = JSON.parse(arr);
            if (Array.isArray(arr)) for (let j = 0, jl = arr.length; j < jl; j++) {
                let items = document.querySelectorAll('[data-catalog*="favorite"][data-catalog*="' + arr[j] + '"]');
                if (items.length) {
                    for (let i = 0, l = items.length; i < l; i++) {
                        items[i].classList.add('is-checked');
                    }
                }
            }
        },

        checkAllItemCompare: function (params, status) {
            let items = document.querySelectorAll('[data-catalog*="compare"][data-catalog*="' + params.id + '"]');
            if (items.length) {
                for (let i = 0, l = items.length; i < l; i++) {
                    if (status === "ADD") {
                        items[i].classList.add('is-active');
                    } else {
                        items[i].classList.remove('is-active');
                    }
                }
            }
        },

        setCompareFromArray: function (arr) {
            if (typeof arr === 'string') arr = JSON.parse(arr);
            if (Array.isArray(arr)) for (let j = 0, jl = arr.length; j < jl; j++) {
                let items = document.querySelectorAll('[data-catalog*="compare"][data-catalog*="' + arr[j] + '"]');
                if (items.length) {
                    for (let i = 0, l = items.length; i < l; i++) {
                        items[i].classList.add('is-active');
                    }
                }
            }
        },

        addBasket: function (item, params) {
            let data = {'PRODUCT_ID': params.id, 'FORM': 'BASKET'};
            BX.showWait();
            BX.ajax({
                url: '/ajax/fp.php',
                data: BX.ajax.prepareData(data),
                method: 'POST',
                dataType: 'json',
                onsuccess: BX.delegate(function (res) {
                    BX.closeWait();
                    if (res && res.RESULT && res.RESULT === 'OK') {

                    } else {
                        console.log(res);
                    }
                }, this),
                onfailure: BX.delegate(function (error) {
                    BX.closeWait();
                    console.log(error)
                }, this)
            });
        },

        toggleFavorite: function (item, params) {
            let data = 'AJAX=Y&ID=' + params.id + '&FORM=FAVORITE';
            BX.showWait();

            BX.ajax.post(this.mainUrl, data, BX.delegate(function (res) {
                BX.closeWait();
                if (res && typeof res === 'string') res = JSON.parse(res);
                if (res && res.RESULT && res.RESULT === 'OK') {
                    if (res.STATUS === "ADD") {
                        item.classList.add('is-checked');
                    } else {
                        item.classList.remove('is-checked');
                    }
                    BX(this.favoriteID).innerHTML = res.COUNT;
                    this.checkAllItemFavorite(params, res.STATUS);
                }
            }, this));
        },

        toggleCompare: function (item, params) {
            let data = 'AJAX=Y&ID=' + params.id + '&FORM=COMPARE';
            BX.showWait();

            BX.ajax.post(this.mainUrl, data, BX.delegate(function (res) {
                BX.closeWait();
                if (res && typeof res === 'string') res = JSON.parse(res);
                if (res && res.RESULT && res.RESULT === 'OK') {
                    if (res.STATUS === "ADD") {
                        item.classList.add('is-active');
                    } else {
                        item.classList.remove('is-active');
                    }
                    this.checkAllItemCompare(params, res.STATUS);
                }
            }, this));
        },

    };
})();

BX.ready(function () {
    window.addEventListener('load', function () {
        BX.Catalog.init();
    })
});
