let widthWindowTwo = document.documentElement.clientWidth;

var getElementOffset = function (el) {
    if (!el || typeof el === 'string') return {top: 0, left: 0};
    var box = el.getBoundingClientRect();
    var body = document.body;
    var docEl = document.documentElement;
    var scrollTop = window.pageYOffset || docEl.scrollTop || body.scrollTop;
    var scrollLeft = window.pageXOffset || docEl.scrollLeft || body.scrollLeft;
    var clientTop = docEl.clientTop || body.clientTop || 0;
    var clientLeft = docEl.clientLeft || body.clientLeft || 0;
    var top = box.top + scrollTop - clientTop;
    var left = box.left + scrollLeft - clientLeft;

    return {
        top: top,
        left: left,
        height: el.clientHeight,
        width: el.clientWidth,
    };
};

var headerScroll = function () {
    let headerScroll = document.getElementById('header');
    let headerHelper = document.querySelector('.header-helper');

    if ((window.scrollY || window.pageYOffset) > (headerHelper.clientHeight + getElementOffset(headerHelper).top)) {
        headerScroll.classList.add('is-sticky');
    } else {
        headerScroll.classList.remove('is-sticky');
    }
};

var  mobileSubmenu = function () {
    let btnOpen = document.querySelectorAll('.catalog-menu__link');

    for (let i = 0; i < btnOpen.length; i++) {
        btnOpen[i].addEventListener('click', function (e) {
            var trigger;
            trigger = e.srcElement || e.target;

            if(trigger.classList.contains('has--menu')) {
                e.preventDefault();
                if (trigger.classList.contains('is-show')) {
                    trigger.classList.remove('is-show')
                } else {
                    trigger.classList.add('is-show')
                }
            }
        })
    }
};

var mobileMenu = function () {
    let burgerMenu = document.querySelector('.header-mobile-burger');
    let menu = document.querySelector('.header-catalog');

    console.log(burgerMenu);

    burgerMenu.addEventListener('click', function () {
        if (menu.classList.contains('is-open')) {
            menu.classList.remove('is-open');
            burgerMenu.classList.remove('is-open');
        } else {
            menu.classList.add('is-open');
            burgerMenu.classList.add('is-open');
        }
    });

    mobileSubmenu();
};

var functionSlider = function () {
    let widthWindow = document.documentElement.clientWidth;
    let stockSlider = document.querySelector('.index-stocks-list');
    let productSliderImage = document.querySelectorAll('.index-product-img-slider');
    let productSlider = document.querySelectorAll('.index-product-list');
    let bannerSlider = document.querySelector('.index-banners-list');
    let specialSlider = document.querySelectorAll('.special-offers-list');
    let tabsSlider = document.querySelectorAll('.offers-tabs-list');
    let productSliderImageElement, productSliderElement, specialSliderElement, tabsSliderElement;

    let defaultsStock = {
        container: stockSlider,
        items: 1,
        slideBy: 1,
        swipeAngle: false,
        nav: true,
        controls: true,
        mouseDrag: true,
        gutter: 30,
        loop: false,
        controlsText: ['<svg><use href="assets/img/svg-icons.svg#slider-arrow-left"></use></svg>', '<svg><use href="assets/img/svg-icons.svg#slider-arrow-right"></use></svg>'],
        "responsive": {
            "767": {
                "items": 2.5    ,
                nav: false
            },
            "1000": {
                "items": 2.8    ,
                nav: false
            },
            "1280": {
                "items": 3,
                nav: false
            }
        },
    };

    let sliderStockElement = tns(defaultsStock);

    let bannerSliderElement = tns({
        container: bannerSlider,
        items: 1,
        slideBy: 1,
        swipeAngle: false,
        nav: true,
        controls: true,
        mouseDrag: true,
        gutter: 0,
        loop: false,
        controlsText: ['<svg><use href="assets/img/svg-icons.svg#slider-arrow-left"></use></svg>', '<svg><use href="assets/img/svg-icons.svg#slider-arrow-right"></use></svg>'],
    });

    for (let i = 0; i < productSlider.length; i++) {
        productSliderElement = tns({
            container: productSlider[i],
            items: 1,
            slideBy: 1,
            swipeAngle: false,
            nav: false,
            controls: true,
            mouseDrag: true,
            gutter: 32,
            loop: false,
            controlsText: ['<svg><use href="assets/img/svg-icons.svg#slider-arrow-left"></use></svg>', '<svg><use href="assets/img/svg-icons.svg#slider-arrow-right"></use></svg>'],
            "responsive": {
                "767": {
                    "items": 3.5,
                },
                "900": {
                    "items": 4,
                },
                "1080": {
                    "items": 4.5,
                },
            },
        })
    }
    ;

    for (let i = 0; i < productSliderImage.length; i++) {
        productSliderImageElement = tns({
            container: productSliderImage[i],
            items: 1,
            slideBy: 1,
            swipeAngle: false,
            nav: true,
            controls: false,
            mouseDrag: false,
            gutter: 0,
            loop: false,
            controlsText: ['<svg><use href="assets/img/svg-icons.svg#slider-arrow-left"></use></svg>', '<svg><use href="assets/img/svg-icons.svg#slider-arrow-right"></use></svg>'],
        })
    }
    ;


    for (let i = 0; i < specialSlider.length; i++) {
        console.log(specialSlider[i]);
        specialSliderElement = tns({
            container: specialSlider[i],
            items: 1,
            slideBy: 1,
            swipeAngle: false,
            nav: true,
            controls: false,
            mouseDrag: true,
            gutter: 30,
            loop: false,
            controlsText: ['<svg><use href="assets/img/svg-icons.svg#slider-arrow-left"></use></svg>', '<svg><use href="assets/img/svg-icons.svg#slider-arrow-right"></use></svg>'],
            "responsive": {
                "767": {
                    "items": 2.5,
                    nav: false,
                    controls: true,
                },
                "1000": {
                    "items": 2.8    ,
                    nav: false,
                    controls: true,
                },
                "1280": {
                    "items": 3,
                    nav: false,
                    controls: true,
                }
            },
        })
    }
    ;

    if (widthWindow < 767) {
        for (let i = 0; i < tabsSlider.length; i++) {
            tabsSliderElement = tns({
                container: tabsSlider[i],
                items: 2.5,
                slideBy: 1,
                "autoWidth": true,
                swipeAngle: false,
                center: true,
                nav: false,
                controls: false,
                mouseDrag: true,
                gutter: 15,
                loop: false
            })
        }
    }
};

var menuHeaderDekstop = function () {
    let menuBtn = document.querySelector('.header-catalog-btn');
    let headerMenu = document.querySelector('.header-catalog');
    let headerBottom = document.querySelector('.header-bottom');

    menuBtn.addEventListener('click', function (e) {
        if (headerBottom.classList.contains('is-menu-open')) {
            headerBottom.classList.remove('is-menu-open');
            menuBtn.classList.remove('is-menu-open');
        } else {
            headerBottom.classList.add('is-menu-open');
            menuBtn.classList.add('is-menu-open');
        }
    });
};

var searchInput = function () {
    let searchInput = document.getElementById('search-input');
    let searchBtn = document.querySelector('.search__icon');

    searchBtn.addEventListener('click', function () {
        if (searchInput.classList.contains('is-show')) {
            searchInput.classList.remove('is-show')
        } else {
            searchInput.classList.add('is-show')
        }
    })
};

var childMenuHeader = function () {
    let menuItems = document.querySelectorAll('.header-menu_link');

    for (let i = 0; i < menuItems.length; i++) {
        menuItems[i].addEventListener('click', function (e) {
            var trigger;
            trigger = e.srcElement || e.target;

            if (trigger.classList.contains('has--child')) {
                e.preventDefault();
                if (trigger.classList.contains('is--open')) {
                    trigger.classList.remove('is--open')
                } else {
                    for (let m = 0; m < menuItems.length; m++) {
                        menuItems[m].classList.remove('is--open');
                    }
                    trigger.classList.add('is--open')
                }
            }
        })
    }
};

var favoriteButtonClick = function () {
    let favoriteBtn = document.querySelectorAll('.index-product_favorite');

    for (let i = 0; i < favoriteBtn.length; i++) {
        favoriteBtn[i].addEventListener('click', function (e) {
            var trigger;
            trigger = e.srcElement || e.target;


        })
    }
};

var mainFunction = function () {
    let widthWindowTwo = document.documentElement.clientWidth;

    if (widthWindowTwo < 861)  {
        mobileMenu();
    }
    searchInput();
    childMenuHeader();
    functionSlider();
    menuHeaderDekstop();
    favoriteButtonClick();
};

window.addEventListener('DOMContentLoaded', mainFunction);

if (widthWindowTwo > 767) {
    window.addEventListener('scroll', headerScroll);
}

