<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Page\Asset;

CJSCore::Init(array('ajax', 'fx', 'popup'));

global $APPLICATION;
global $USER;
global $siteSettings;
//global $isIndex, $isCatalog, $isDetail, $isCatalogCategories, $isAdditional, $isInstallCenters, $isServices, $hasContainer, $isOrderListing, $isResult;
//global $phone, $subtitle, $basket, $compare, $car, $current_step, $title, $arCities, $stage, $filter_list;

?>
<!DOCTYPE html>
<html class="no-js" lang="ru">
<head>
    <? $APPLICATION->ShowHead(); ?>
    <title><? $APPLICATION->ShowTitle(); ?></title>

    <?
    Asset::getInstance()->addString('<meta charset="utf-8">');
    Asset::getInstance()->addString('<meta http-equiv="x-ua-compatible" content="ie=edge">');
    Asset::getInstance()->addString('<meta name="description" content="">');
    Asset::getInstance()->addString('<meta name="viewport" content="width=device-width, initial-scale=1">');
    Asset::getInstance()->addString('<link rel="preconnect" href="https://fonts.googleapis.com">');
    Asset::getInstance()->addString('<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>');

    Asset::getInstance()->addString('<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">');
    Asset::getInstance()->addString('<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">');
    Asset::getInstance()->addString('<link href="https://fonts.googleapis.com/css2?family=Exo:wght@400;500&display=swap" rel="stylesheet">');

    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/assets/css/animation.min.css");
    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/assets/css/normalize.min.css");
    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/assets/plugins/tinyslider/tiny-slider.min.css");
    Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . "/assets/css/main.css");

    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/assets/plugins/tinyslider/tiny-slider.min.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/assets/js/tabs.min.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/assets/js/main.js');
    Asset::getInstance()->addJs(SITE_TEMPLATE_PATH . '/assets/js/catalog.min.js');

    ?>

</head>
<body id="body">
<div id="panel">
    <?php $APPLICATION->ShowPanel(); ?>
</div>

<div class="wrapper">
    <header class="header <? if (!$isIndex) : ?> is-not-main <? endif; ?>"
            id="header">
        <div class="header-top">
            <div class="container">
                <div class="header-top-left mb--hidden">
                    <div class="header-social">
                        <ul class="header-social-list">
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--facebook">
                                        <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#facebook"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--twitter">
                                        <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#twitter"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--youtube">
                                        <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#youtube"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--insta">
                                        <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#instagram"></use>
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a class="header-social_link" href="#" target="_blank">
                                    <svg class="social_icon icon--telegram">
                                        <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#telegram"></use>
                                    </svg>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <a href="#" target="_blank" class="header-slogan">Наши товары на маркетплейсах</a>
                </div>
                <a href="javascript:void(0);" class="header-mobile-burger header-catalog-burger mb--visible">
                    <i></i>
                </a>
                <div class="header-menu mb--hidden">
                    <? $APPLICATION->IncludeComponent(
                        "bitrix:menu",
                        "top_menu-right",
                        array(
                            "ALLOW_MULTI_SELECT" => "N",
                            "CHILD_MENU_TYPE" => "top",
                            "DELAY" => "N",
                            "MAX_LEVEL" => "2",
                            "MENU_CACHE_GET_VARS" => array(""),
                            "MENU_CACHE_TIME" => "3600",
                            "MENU_CACHE_TYPE" => "N",
                            "MENU_CACHE_USE_GROUPS" => "Y",
                            "ROOT_MENU_TYPE" => "top2",
                            "USE_EXT" => "N"
                        )
                    ); ?>
                </div>

                <a class="header-phone" href="tel:+73832119683">
                    <svg class="header-phone_icon">
                        <use href="<?= $siteSettings["PATH_IMG_PHONE"]; ?>"></use>
                    </svg>
                    <?= $siteSettings["NUMBER"]; ?>
                </a>
            </div>
        </div>
        <div class="header-bottom">
            <div class="container">
                <a class="header-logo logo--big" href="#"><img src="<?= $siteSettings["PATH_LOGO"]; ?>" alt=""></a>
                <a class="header-logo logo--small" href="#"><img src="<?= $siteSettings["PATH_LOGO_SMALL"]; ?>" alt=""></a>
                <a href="javascript:void(0);" class="header-catalog-btn button mb--hidden">
                        <span class="header-catalog-burger">
                            <i></i>
                        </span>
                    <span>Каталог</span>
                </a>


                <div class="header-menu is-scroll-visible mb--hidden">
                    <? $APPLICATION->IncludeComponent(
                        "bitrix:menu",
                        "top_menu-right",
                        array(
                            "ALLOW_MULTI_SELECT" => "N",
                            "CHILD_MENU_TYPE" => "top",
                            "DELAY" => "N",
                            "MAX_LEVEL" => "2",
                            "MENU_CACHE_GET_VARS" => array(""),
                            "MENU_CACHE_TIME" => "3600",
                            "MENU_CACHE_TYPE" => "N",
                            "MENU_CACHE_USE_GROUPS" => "Y",
                            "ROOT_MENU_TYPE" => "top2",
                            "USE_EXT" => "N"
                        )
                    ); ?>
                </div>


                <div class="header-catalog">
                    <div class="index-catalog-list">

                    <? $APPLICATION->IncludeComponent(
                        "bitrix:catalog.section.list",
                        "catalog",
                        array(
                            "ADD_SECTIONS_CHAIN" => "N",
                            "CACHE_FILTER" => "N",
                            "CACHE_GROUPS" => "Y",
                            "CACHE_TIME" => "36000000",
                            "CACHE_TYPE" => "N",
                            "COUNT_ELEMENTS" => "Y",
                            "COUNT_ELEMENTS_FILTER" => "CNT_ACTIVE",
                            "FILTER_NAME" => "sectionsFilter",
                            "IBLOCK_ID" => IB_catalog,
                            "IBLOCK_TYPE" => "catalog",
                            "SECTION_CODE" => "",
                            "SECTION_FIELDS" => array(
                                0 => "NAME",
                                1 => "",
                            ),
                            "SECTION_ID" => $_REQUEST["SECTION_ID"],
                            "SECTION_URL" => "",
                            "SECTION_USER_FIELDS" => array(
                                0 => "",
                                1 => "",
                            ),
                            "SHOW_PARENT_NAME" => "Y",
                            "TOP_DEPTH" => "3",
                            "VIEW_MODE" => "LIST",
                            "COMPONENT_TEMPLATE" => "catalog",
                            "SHOW_ANGLE" => "Y",
                            "OFFSET_MODE" => "N"
                        ),
                        false
                    ); ?>

                    </div>
                </div>

                <div class="header-search">
                    <form class="search-form">
                        <input type="search" class="search-input" id="search-input" placeholder="Искать товары">
                        <button class="search-button">
                            <svg>
                                <use href="<?= SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#search-btn"></use>
                            </svg>
                        </button>
                        <a href="javascript:void(0);" class="is-scroll-visible search__icon">
                            <svg>
                                <use href="<?= SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#search-btn"></use>
                            </svg>
                        </a>
                    </form>
                </div>
                <div class="header-button-list">
                    <a href="#" class="header-compare header-button--flex">
                        <svg class="header-compare__icon header-button_icon">
                            <use href="<?= SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#compare"></use>
                        </svg>
                        <span>Сравнение</span>
                    </a>
                    <a href="#" class="header-favorite header-button--flex">
                        <svg class="header-favorite__icon header-button_icon">
                            <use href="<?= SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#favorite"></use>
                        </svg>
                        <span class="header-favorite__label" id="header-favorite">125</span>
                        <span>Избранное</span>
                    </a>
                    <a href="#" data-modal-target="enter" data-modal-url="/ajax/forms/enter.php"
                       class="header-enter header-button--flex">
                        <svg class="header-enter__icon header-button_icon">
                            <use href="<?= SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#enter"></use>
                        </svg>
                        <span>Войти</span>
                    </a>
                    <a href="#" class="header-basket header-button--flex">
                        <svg class="header-basket__icon header-button_icon">
                            <use href="<?= SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#basket"></use>
                        </svg>
                        <span class="header-basket__label" id="header-basket">7</span>
                        <span>Корзина</span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="header-helper"></div>
