<div class="login-modal" id="login-modal">
    <div class="popup-title">Авторизация</div>
    <div class="popap--content login-content">
        <form class="form login-form" id="login-form_id" action="" method="post">
            <div class="input-wrap">
                <label class="label-item" for="EMAIL">Имя</label>
                <input type="text" data-rule="email" class="input-item" name="EMAIL" id="EMAIL" required>
            </div>
            <div class="input-wrap">
                <label class="label-item" for="PASSWORD">Пароль</label>
                <input type="password" name="PASSWORD" id="PASSWORD" class="input--item" required>
            </div>
            <button type="submit" class="button submit">Войти</button>
        </form>
    </div>
</div>