<footer class="footer" id="footer">
    <div class="container">
        <div class="footer-top">
            <a href="/" class="footer-logo"><img src="<?= $siteSettings["PATH_LOGO_FOOTER"]; ?>" alt=""></a>

            <div class="footer-menu mb--hidden">
                <? $APPLICATION->IncludeComponent("bitrix:menu", "footer_menu", array(
                    "ALLOW_MULTI_SELECT" => "N",    // Разрешить несколько активных пунктов одновременно
                    "CHILD_MENU_TYPE" => "top",    // Тип меню для остальных уровней
                    "DELAY" => "N",    // Откладывать выполнение шаблона меню
                    "MAX_LEVEL" => "2",    // Уровень вложенности меню
                    "MENU_CACHE_GET_VARS" => array(    // Значимые переменные запроса
                        0 => "",
                    ),
                    "MENU_CACHE_TIME" => "3600",    // Время кеширования (сек.)
                    "MENU_CACHE_TYPE" => "N",    // Тип кеширования
                    "MENU_CACHE_USE_GROUPS" => "Y",    // Учитывать права доступа
                    "ROOT_MENU_TYPE" => "top2",    // Тип меню для первого уровня
                    "USE_EXT" => "N",    // Подключать файлы с именами вида .тип_меню.menu_ext.php
                ),
                    false
                ); ?>

            </div>
            <div class="footer-pay-social mb--hidden">
                <div class="footer-pay">
                    <div class="footer-title">Способы оплаты</div>
                    <ul class="footer-pay-list">
                        <li class="footer-pay_item">
                            <img src="<?= $siteSettings["PATH_LOGO_MASTER"]; ?>" alt="">
                        </li>
                        <li class="footer-pay_item">
                            <img src="<?= $siteSettings["PATH_LOGO_MAESTRO"]; ?>" alt="">
                        </li>
                        <li class="footer-pay_item">
                            <img src="<?= $siteSettings["PATH_LOGO_VISA"]; ?>" alt="">
                        </li>
                    </ul>
                </div>
                <div class="footer--delimer"></div>

                <div class="footer-social">
                    <ul class="footer-social-list">
                        <li>
                            <a class="footer-social_link" href="#" target="_blank">
                                <svg class="social_icon icon--facebook">
                                    <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#facebook"></use>
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a class="footer-social_link" href="#" target="_blank">
                                <svg class="social_icon icon--twitter">
                                    <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#twitter"></use>
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a class="footer-social_link" href="#" target="_blank">
                                <svg class="social_icon icon--youtube">
                                    <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#youtube"></use>
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a class="footer-social_link" href="#" target="_blank">
                                <svg class="social_icon icon--insta">
                                    <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#instagram"></use>
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a class="footer-social_link" href="#" target="_blank">
                                <svg class="social_icon icon--telegram">
                                    <use href="<?= SITE_TEMPLATE_PATH; ?>/assets/img/svg-icons.svg#telegram"></use>
                                </svg>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="footer-contacts mb--hidden">
                <a href="tel:+73832119683" class="footer-phone">
                    <svg class="footer-phone_icon">
                        <use href="<?= $siteSettings["PATH_IMG_PHONE"]; ?>"></use>
                    </svg>
                    <?= $siteSettings["NUMBER"]; ?>
                </a>

                <div class="footer-title">Подписаться на новости и скидки</div>
<!--                <form class="form form-subscribe" action="" method="get">-->
<!--                    <input type="email" class="input-subscribe" data-rule="email" id="input-subscribe"-->
<!--                           placeholder="Введите свой Email">-->
<!--                    <button type="submit" class="button-subscribe">-->
<!--                        <svg class="button-subscribe_icon">-->
<!--                            <use href="--><?//= SITE_TEMPLATE_PATH ?><!--/assets/img/svg-icons.svg#subscribe-arrow"></use>-->
<!--                        </svg>-->
<!--                    </button>-->
<!--                </form>-->

                <?$APPLICATION->IncludeComponent("bitrix:sender.subscribe", "spam_subscribe", Array(
	"AJAX_MODE" => "Y",	// Включить режим AJAX
		"AJAX_OPTION_ADDITIONAL" => "",	// Дополнительный идентификатор
		"AJAX_OPTION_HISTORY" => "N",	// Включить эмуляцию навигации браузера
		"AJAX_OPTION_JUMP" => "N",	// Включить прокрутку к началу компонента
		"AJAX_OPTION_STYLE" => "Y",	// Включить подгрузку стилей
		"CACHE_TIME" => "3600",	// Время кеширования (сек.)
		"CACHE_TYPE" => "A",	// Тип кеширования
		"CONFIRMATION" => "N",	// Запрашивать подтверждение подписки по email
		"HIDE_MAILINGS" => "N",	// Скрыть список рассылок, и подписывать на все
		"SET_TITLE" => "N",	// Устанавливать заголовок страницы
		"SHOW_HIDDEN" => "N",	// Показать скрытые рассылки для подписки
		"USER_CONSENT" => "N",	// Запрашивать согласие
		"USER_CONSENT_ID" => "0",	// Соглашение
		"USER_CONSENT_IS_CHECKED" => "Y",	// Галка по умолчанию проставлена
		"USER_CONSENT_IS_LOADED" => "N",	// Загружать текст сразу
		"USE_PERSONALIZATION" => "Y",	// Определять подписку текущего пользователя
	),
	false
);?>

            </div>
        </div>
        <div class="footer-bottom">
            <div class="footer-bottom-left">
                <div class="footer-bottom--delimer">
                    <svg>
                        <use href="<?= SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#footer-volna"></use>
                    </svg>
                </div>
                <div class="footer-copyright">© Сибирский дом техники 2021</div>
            </div>
            <div class="footer-bottom-right">
                <a href="#" class="footer-policy" target="_blank">Политика конфиденциальности</a>
                <div class="footer--delimer mb--hidden"></div>
                <a href="https://www.airws.ru/" class="footer-developer">Разработка сайта — AiR</a>
            </div>
        </div>
    </div>
</footer>

</div>
</body>
</html>