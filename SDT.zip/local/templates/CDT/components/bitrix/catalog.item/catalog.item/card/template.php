<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $item
 * @var array $Prop
 * @var array $actualItem
 * @var array $minOffer
 * @var array $itemIds
 * @var array $ITEM_PROPERTY
 * @var array $price
 * @var array $measureRatio
 * @var bool $haveOffers
 * @var bool $showSubscribe
 * @var array $morePhoto
 * @var bool $showSlider
 * @var bool $itemHasDetailUrl
 * @var string $imgTitle
 * @var string $productTitle
 * @var string $buttonSizeClass
 * @var CatalogSectionComponent $component
 */
?>
<?
//var_dump($item['PROPERTIES']['ATT_SMART_FILTER']['VALUE']);
//echo '<pre>';
//var_dump($ITEM_PROPERTY);
//echo '</pre>';

if ($item['PROPERTIES']['ATT_SMART_FILTER']['VALUE'] == $ITEM_PROPERTY) {

    ?>
    <div class="index-product-item">
    <div class="index-product-container"><?
        if ($item['PROPERTIES']['ATT_NEW'] == 'Да') {
            ?>
            <span class="index-product-tag is-new"><?= $item['PROPERTIES']['ATT_NEW']['NAME'] ?></span>
        <?
        } elseif ($item['PROPERTIES']['ATT_ONLY']['VALUE'] == 'Да') {
            ?>
            <span class="index-product-tag is-only"><?= $item['PROPERTIES']['ATT_ONLY']['NAME'] ?></span>
        <?
        } elseif ($item['PROPERTIES']['ATT_BESTCELLER']['VALUE'] == 'Да') {
            ?>
            <span class="index-product-tag is-bestaller"><?= $item['PROPERTIES']['ATT_BESTCELLER']['NAME'] ?></span>
        <?
        }

        ?>
        <div class="index-product_buttons">
            <a href="#" class="index-product_compare" data-catalog="{'action':'compare','id':'38'}">
                <svg>
                    <use href="<? SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#product-compare"></use>
                </svg>
            </a>
            <a href="#" class="index-product_favorite" data-catalog="{'action':'favorite','id':'38'}">
                <svg class="is-not-active">
                    <use href="<? SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#product-favorite"></use>
                </svg>
                <svg class="is-active">
                    <use href="<? SITE_TEMPLATE_PATH ?>/assets/img/svg-icons.svg#product-favorite-active"></use>
                </svg>
            </a>
        </div>

        <div class="index-product-img-slider">
            <? // additional photos
            $LINE_ELEMENT_COUNT = 2; // number of elements in a row
            ?>
            <? foreach ($item["MORE_PHOTO"] as $PHOTO):?>
                <a href="#" class="index-product_img">
                    <img border="0" src="<?= $PHOTO["SRC"] ?>" width="<?= $PHOTO["WIDTH"] ?>"
                         height="<?= $PHOTO["HEIGHT"] ?>"
                         alt="<?= $item["NAME"] ?>" title="<?= $item["NAME"] ?>"/>
                </a>
            <?endforeach ?>
        </div>

        <div class="index-product_name">
            <? if ($itemHasDetailUrl): ?>
            <? endif; ?>
            <?= $productTitle ?>
            <? if ($itemHasDetailUrl): ?>
            <? endif; ?>
        </div>
        <?
        if (!empty($arParams['PRODUCT_BLOCKS_ORDER'])) {
            foreach ($arParams['PRODUCT_BLOCKS_ORDER'] as $blockName) {
                switch ($blockName) {
                    case 'price': ?>
                        <div class="index-product_price">
                            <div class="is-new-price">
                                <?
                                if (!empty($price)) {
                                    if ($arParams['PRODUCT_DISPLAY_MODE'] === 'N' && $haveOffers) {
                                        echo Loc::getMessage(
                                            'CT_BCI_TPL_MESS_PRICE_SIMPLE_MODE',
                                            array(
                                                '#PRICE#' => $price['PRINT_RATIO_PRICE'],
                                                '#VALUE#' => $measureRatio,
                                                '#UNIT#' => $minOffer['ITEM_MEASURE']['TITLE']
                                            )
                                        );
                                    } else {
                                        echo number_format($item['PROPERTIES']['ATT_PRICE']['VALUE'], 0, ',', ' ') . ' руб.';
                                    }
                                }
                                ?>
                            </div>
                            <?
                            if ($arParams['SHOW_OLD_PRICE'] === 'Y') {
                                if ($item['PROPERTIES']['ATT_OLD_PRICE']['VALUE'] != null) {
                                    ?>
                                    <div class="is-old-price">
                                        <!--                                --><?//=$price['PRINT_RATIO_BASE_PRICE']
                                        ?>
                                        <!--                                --><?//$arSKU = CCatalogSKU::getOffersList($item[ID], 0, array('ACTIVE' => 'Y'), array('NAME'), array('HEIGHT', 'WIDTH'));
                                        ?>
                                        <?= number_format($item['PROPERTIES']['ATT_OLD_PRICE']['VALUE'], 0, ',', ' ') . ' руб.'; ?>
                                    </div>
                                <?
                                }
                            }
                            ?>
                        </div>
                        <?
                        break;

                    case 'quantityLimit':
                        if ($arParams['SHOW_MAX_QUANTITY'] !== 'N') {
                            if ($haveOffers) {
                                if ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y') {
                                    ?>
                                    <a href="#" class="index-product_basket button">В корзину</a>
                                    <?
                                }
                            } else {
                                if (
                                    $measureRatio
                                    && (float)$actualItem['CATALOG_QUANTITY'] > 0
                                    && $actualItem['CATALOG_QUANTITY_TRACE'] === 'Y'
                                    && $actualItem['CATALOG_CAN_BUY_ZERO'] === 'N'
                                ) {
                                    ?>
                                    <a href="#" class="index-product_basket button">В корзину</a>
                                    <?
                                }
                            }
                        }

                        break;

                    case 'quantity':
                        if (!$haveOffers) {
                            if ($actualItem['CAN_BUY'] && $arParams['USE_PRODUCT_QUANTITY']) {
                                ?>
                                <a href="#" class="index-product_basket button">В корзину</a>
                                <?
                            }
                        } elseif ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y') {
                            if ($arParams['USE_PRODUCT_QUANTITY']) {
                                ?>
                                <a href="#" class="index-product_basket button">В корзину</a>
                                <?
                            }
                        }

                        break;

                    case 'buttons':
                        ?>
                        <a href="#" class="index-product_basket button">В корзину</a>
                        <?
                        break;

                    case 'props':
                        if (!$haveOffers) {
                            if (!empty($item['DISPLAY_PROPERTIES'])) {
                                ?>
                                <a href="#" class="index-product_basket button">В корзину</a>
                                <?
                            }

                            if ($arParams['ADD_PROPERTIES_TO_BASKET'] === 'Y' && !empty($item['PRODUCT_PROPERTIES'])) {
                                ?>
                                <div id="<?= $itemIds['BASKET_PROP_DIV'] ?>" style="display: none;">
                                    <?
                                    if (!empty($item['PRODUCT_PROPERTIES_FILL'])) {
                                        foreach ($item['PRODUCT_PROPERTIES_FILL'] as $propID => $propInfo) {
                                            ?>
                                            <input type="hidden"
                                                   name="<?= $arParams['PRODUCT_PROPS_VARIABLE'] ?>[<?= $propID ?>]"
                                                   value="<?= htmlspecialcharsbx($propInfo['ID']) ?>">
                                            <?
                                            unset($item['PRODUCT_PROPERTIES'][$propID]);
                                        }
                                    }

                                    if (!empty($item['PRODUCT_PROPERTIES'])) {
                                        ?>
                                        <table>
                                            <?
                                            foreach ($item['PRODUCT_PROPERTIES'] as $propID => $propInfo) {
                                                ?>
                                                <tr>
                                                    <td><?= $item['PROPERTIES'][$propID]['NAME'] ?></td>
                                                    <td>
                                                        <?
                                                        if (
                                                            $item['PROPERTIES'][$propID]['PROPERTY_TYPE'] === 'L'
                                                            && $item['PROPERTIES'][$propID]['LIST_TYPE'] === 'C'
                                                        ) {
                                                            foreach ($propInfo['VALUES'] as $valueID => $value) {
                                                                ?>
                                                                <label>
                                                                    <? $checked = $valueID === $propInfo['SELECTED'] ? 'checked' : ''; ?>
                                                                    <input type="radio"
                                                                           name="<?= $arParams['PRODUCT_PROPS_VARIABLE'] ?>[<?= $propID ?>]"
                                                                           value="<?= $valueID ?>" <?= $checked ?>>
                                                                    <?= $value ?>
                                                                </label>
                                                                <br/>
                                                                <?
                                                            }
                                                        } else {
                                                            ?>
                                                            <select name="<?= $arParams['PRODUCT_PROPS_VARIABLE'] ?>[<?= $propID ?>]">
                                                                <?
                                                                foreach ($propInfo['VALUES'] as $valueID => $value) {
                                                                    $selected = $valueID === $propInfo['SELECTED'] ? 'selected' : '';
                                                                    ?>
                                                                    <option value="<?= $valueID ?>" <?= $selected ?>>
                                                                        <?= $value ?>
                                                                    </option>
                                                                    <?
                                                                }
                                                                ?>
                                                            </select>
                                                            <?
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <?
                                            }
                                            ?>
                                        </table>
                                        <?
                                    }
                                    ?>
                                </div>
                                <?
                            }
                        } else {
                            $showProductProps = !empty($item['DISPLAY_PROPERTIES']);
                            $showOfferProps = $arParams['PRODUCT_DISPLAY_MODE'] === 'Y' && $item['OFFERS_PROPS_DISPLAY'];

                            if ($showProductProps || $showOfferProps) {
                                ?>
                                <a href="#" class="index-product_basket button">В корзину</a>
                                <?
                            }
                        }

                        break;

                    case 'sku':
                        if ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y' && $haveOffers && !empty($item['OFFERS_PROP'])) {
                            ?>
                            <div id="<?= $itemIds['PROP_DIV'] ?>">
                                <?
                                foreach ($arParams['SKU_PROPS'] as $skuProperty) {
                                    $propertyId = $skuProperty['ID'];
                                    $skuProperty['NAME'] = htmlspecialcharsbx($skuProperty['NAME']);
                                    if (!isset($item['SKU_TREE_VALUES'][$propertyId]))
                                        continue;
                                    ?>
                                    <a href="#" class="index-product_basket button">В корзину</a>
                                    <?
                                }
                                ?>
                            </div>
                            <?
                            foreach ($arParams['SKU_PROPS'] as $skuProperty) {
                                if (!isset($item['OFFERS_PROP'][$skuProperty['CODE']]))
                                    continue;

                                $skuProps[] = array(
                                    'ID' => $skuProperty['ID'],
                                    'SHOW_MODE' => $skuProperty['SHOW_MODE'],
                                    'VALUES' => $skuProperty['VALUES'],
                                    'VALUES_COUNT' => $skuProperty['VALUES_COUNT']
                                );
                            }

                            unset($skuProperty, $value);

                            if ($item['OFFERS_PROPS_DISPLAY']) {
                                foreach ($item['JS_OFFERS'] as $keyOffer => $jsOffer) {
                                    $strProps = '';

                                    if (!empty($jsOffer['DISPLAY_PROPERTIES'])) {
                                        foreach ($jsOffer['DISPLAY_PROPERTIES'] as $displayProperty) {
                                            $strProps .= '<dt>' . $displayProperty['NAME'] . '</dt><dd>'
                                                . (is_array($displayProperty['VALUE'])
                                                    ? implode(' / ', $displayProperty['VALUE'])
                                                    : $displayProperty['VALUE'])
                                                . '</dd>';
                                        }
                                    }

                                    $item['JS_OFFERS'][$keyOffer]['DISPLAY_PROPERTIES'] = $strProps;
                                }
                                unset($jsOffer, $strProps);
                            }
                        }

                        break;
                }
            }
        }

        if (
            $arParams['DISPLAY_COMPARE']
            && (!$haveOffers || $arParams['PRODUCT_DISPLAY_MODE'] === 'Y')
        ) {
            ?>
            <div class="product-item-compare-container">
                <div class="product-item-compare">
                    <div class="checkbox">
                        <label id="<?= $itemIds['COMPARE_LINK'] ?>">
                            <input type="checkbox" data-entity="compare-checkbox">
                            <span data-entity="compare-title"><?= $arParams['MESS_BTN_COMPARE'] ?></span>
                        </label>
                    </div>
                </div>
            </div>
            <?
        }
        ?></div></div><?
}
?>