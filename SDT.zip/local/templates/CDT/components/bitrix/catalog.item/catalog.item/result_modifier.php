<?
/**
 * @var array $arResult
 */

//var_dump($arResult['ITEM']["PROPERTIES"]);

//$res = CIBlockElement::GetProperty($arResult['ITEM']['IBLOCK_ID'], $arResult['ITEM']['ID']);
//while ($row = $res->Fetch())
//{
//    if ($row['CODE']=='number'){$arResult['NUM_PHONE'] = $row['VALUE'];}
//    if ($row['CODE']=='path_img'){$arResult['PATH_IMG'] = $row['VALUE'];}
//}



$item["MORE_PHOTO"] = array();
if(isset($item["PROPERTIES"]["MORE_PHOTO"]["VALUE"]) && is_array($item["PROPERTIES"]["MORE_PHOTO"]["VALUE"]))
{
    foreach($item["PROPERTIES"]["MORE_PHOTO"]["VALUE"] as $FILE)
    {
        $FILE = CFile::GetFileArray($FILE);
        if(is_array($FILE))
            $item["MORE_PHOTO"][]=$FILE;
    }
}

//var_dump($item);

?>