<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main\Localization\Loc;

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $item
 * @var array $actualItem
 * @var array $minOffer
 * @var array $itemIds
 * @var array $price
 * @var array $measureRatio
 * @var bool $haveOffers
 * @var bool $showSubscribe
 * @var array $morePhoto
 * @var bool $showSlider
 * @var bool $itemHasDetailUrl
 * @var string $imgTitle
 * @var string $productTitle
 * @var string $buttonSizeClass
 * @var CatalogSectionComponent $component
 */

if ($item['LABEL'])
{
    ?>
    <?
    if (!empty($item['LABEL_ARRAY_VALUE']))
    {
        foreach ($item['LABEL_ARRAY_VALUE'] as $code => $value)
        {
            if ($value=='Лидер продаж'){?>
                <span<?=(!isset($item['LABEL_PROP_MOBILE'][$code]) ? ' class="index-product-tag is-only' : '')?> title="<?=$value?>"><?=$value?>
						    </span>
            <?}elseif ($value=='Новинка'){?>
                <span<?=(!isset($item['LABEL_PROP_MOBILE'][$code]) ? ' class="index-product-tag is-new' : '')?> title="<?=$value?>"><?=$value?>
						    </span>
            <?}elseif ($value=='Спецпредложение'){?>
                <span<?=(!isset($item['LABEL_PROP_MOBILE'][$code]) ? ' class="index-product-tag is-bestaller' : '')?> title="<?=$value?>"><?=$value?>
						    </span>
            <?}
        }
    }
    ?>
    <?
}?>
    <div class="index-product-img-slider">
        <?foreach ($morePhoto as $key => $photo){?>
            <a href="#" class="index-product_img">
                <img src="<?=$photo['SRC']?>" alt="">
            </a>
        <?}?>
    </div>

<?
if ($item['SECOND_PICT'])
{
    $bgImage = !empty($item['PREVIEW_PICTURE_SECOND']) ? $item['PREVIEW_PICTURE_SECOND']['SRC'] : $item['PREVIEW_PICTURE']['SRC'];
    ?>
    <span class="product-item-image-alternative" id="<?=$itemIds['SECOND_PICT']?>"
          style="background-image: url('<?=$bgImage?>'); <?=($showSlider ? 'display: none;' : '')?>">
			</span>
    <?
}

if ($arParams['SHOW_DISCOUNT_PERCENT'] === 'Y')
{
    ?>
    <div class="product-item-label-ring <?=$discountPositionClass?>" id="<?=$itemIds['DSC_PERC']?>"
        <?=($price['PERCENT'] > 0 ? '' : 'style="display: none;"')?>>
        <span><?=-$price['PERCENT']?>%</span>
    </div>
    <?
}


?>
    <div class="index-product_buttons">
        <a href="#" class="index-product_compare" data-catalog="{'action':'compare','id':'38'}">
            <svg>
                <use href="assets/img/svg-icons.svg#product-compare"></use>
            </svg>
        </a>
        <a href="#" class="index-product_favorite" data-catalog="{'action':'favorite','id':'38'}">
            <svg class="is-not-active">
                <use href="assets/img/svg-icons.svg#product-favorite"></use>
            </svg>
            <svg class="is-active">
                <use href="assets/img/svg-icons.svg#product-favorite-active"></use>
            </svg>
        </a>
    </div><?
?>

<?
if ($arParams['SLIDER_PROGRESS'] === 'Y')
{
    ?>
    <div class="product-item-image-slider-progress-bar-container">
        <div class="product-item-image-slider-progress-bar" id="<?=$itemIds['PICT_SLIDER']?>_progress_bar" style="width: 0;"></div>
    </div>
    <?
}
?>
<? if ($itemHasDetailUrl): ?>
    </a>
<? else: ?>
    </span>
<? endif; ?>
    <div class="index-product_name">
        <? if ($itemHasDetailUrl): ?>
            <!--		<a href="--><?//=$item['DETAIL_PAGE_URL']?><!--" title="--><?//=$productTitle?><!--">-->
        <? endif; ?>
        <?=$productTitle?>
        <? if ($itemHasDetailUrl): ?>
            </a>
        <? endif; ?>
    </div>
<?
if (!empty($arParams['PRODUCT_BLOCKS_ORDER']))
{
    foreach ($arParams['PRODUCT_BLOCKS_ORDER'] as $blockName)
    {
        switch ($blockName)
        {
            case 'price': ?>
                <div class="index-product_price" data-entity="price-block">
                    <?
                    if ($arParams['SHOW_OLD_PRICE'] === 'Y')
                    {
                        ?>
                        <div class="is-old-price" id="<?=$itemIds['PRICE_OLD']?>"
                            <?=($price['RATIO_PRICE'] >= $price['RATIO_BASE_PRICE'] ? 'style="display: none;"' : '')?>>
                            <?=$price['PRINT_RATIO_BASE_PRICE']?>
                        </div>&nbsp;
                        <?
                    }
                    ?>
                    <div class="is-new-price" id="<?=$itemIds['PRICE']?>">
                        <?
                        if (!empty($price))
                        {
                            echo number_format($price['PRICE'],0, '', ' ').' руб.';
                        }
                        ?>
                    </div>
                </div>
                <?
                break;

            case 'quantityLimit':
                if ($arParams['SHOW_MAX_QUANTITY'] !== 'N')
                {
                    if ($haveOffers)
                    {
                        if ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y')
                        {
                            ?>
                            <div class="product-item-info-container product-item-hidden" id="<?=$itemIds['QUANTITY_LIMIT']?>"
                                 style="display: none;" data-entity="quantity-limit-block">
                                <div class="product-item-info-container-title">
                                    <?=$arParams['MESS_SHOW_MAX_QUANTITY']?>:
                                    <span class="product-item-quantity" data-entity="quantity-limit-value"></span>
                                </div>
                            </div>
                            <?
                        }
                    }
                    else
                    {
                        if (
                            $measureRatio
                            && (float)$actualItem['CATALOG_QUANTITY'] > 0
                            && $actualItem['CATALOG_QUANTITY_TRACE'] === 'Y'
                            && $actualItem['CATALOG_CAN_BUY_ZERO'] === 'N'
                        )
                        {
                            ?>
                            <div class="product-item-info-container product-item-hidden" id="<?=$itemIds['QUANTITY_LIMIT']?>">
                                <div class="product-item-info-container-title">
                                    <?=$arParams['MESS_SHOW_MAX_QUANTITY']?>:
                                    <span class="product-item-quantity">
											<?
                                            if ($arParams['SHOW_MAX_QUANTITY'] === 'M')
                                            {
                                                if ((float)$actualItem['CATALOG_QUANTITY'] / $measureRatio >= $arParams['RELATIVE_QUANTITY_FACTOR'])
                                                {
                                                    echo $arParams['MESS_RELATIVE_QUANTITY_MANY'];
                                                }
                                                else
                                                {
                                                    echo $arParams['MESS_RELATIVE_QUANTITY_FEW'];
                                                }
                                            }
                                            else
                                            {
                                                echo $actualItem['CATALOG_QUANTITY'].' '.$actualItem['ITEM_MEASURE']['TITLE'];
                                            }
                                            ?>
										</span>
                                </div>
                            </div>
                            <?
                        }
                    }
                }

                break;

            case 'quantity':
                if (!$haveOffers)
                {
                    if ($actualItem['CAN_BUY'] && $arParams['USE_PRODUCT_QUANTITY'])
                    {
                        ?>
                        <div class="product-item-info-container product-item-hidden" data-entity="quantity-block">
                            <div class="product-item-amount">
                                <div class="product-item-amount-field-container">
                                    <span class="product-item-amount-field-btn-minus no-select" id="<?=$itemIds['QUANTITY_DOWN']?>"></span>
                                    <input class="product-item-amount-field" id="<?=$itemIds['QUANTITY']?>" type="number"
                                           name="<?=$arParams['PRODUCT_QUANTITY_VARIABLE']?>"
                                           value="<?=$measureRatio?>">
                                    <span class="product-item-amount-field-btn-plus no-select" id="<?=$itemIds['QUANTITY_UP']?>"></span>
                                    <span class="product-item-amount-description-container">
											<span id="<?=$itemIds['QUANTITY_MEASURE']?>">
												<?=$actualItem['ITEM_MEASURE']['TITLE']?>
											</span>
											<span id="<?=$itemIds['PRICE_TOTAL']?>"></span>
										</span>
                                </div>
                            </div>
                        </div>
                        <?
                    }
                }
                elseif ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y')
                {
                    if ($arParams['USE_PRODUCT_QUANTITY'])
                    {
                        ?>
                        <div class="product-item-info-container product-item-hidden" data-entity="quantity-block">
                            <div class="product-item-amount">
                                <div class="product-item-amount-field-container">
                                    <span class="product-item-amount-field-btn-minus no-select" id="<?=$itemIds['QUANTITY_DOWN']?>"></span>
                                    <input class="product-item-amount-field" id="<?=$itemIds['QUANTITY']?>" type="number"
                                           name="<?=$arParams['PRODUCT_QUANTITY_VARIABLE']?>"
                                           value="<?=$measureRatio?>">
                                    <span class="product-item-amount-field-btn-plus no-select" id="<?=$itemIds['QUANTITY_UP']?>"></span>
                                    <span class="product-item-amount-description-container">
											<span id="<?=$itemIds['QUANTITY_MEASURE']?>"><?=$actualItem['ITEM_MEASURE']['TITLE']?></span>
											<span id="<?=$itemIds['PRICE_TOTAL']?>"></span>
										</span>
                                </div>
                            </div>
                        </div>
                        <?
                    }
                }

                break;

            case 'buttons':
                ?>
                <a href="#" class="index-product_basket button">В корзину</a>
                <?
                break;

            case 'sku':
                if ($arParams['PRODUCT_DISPLAY_MODE'] === 'Y' && $haveOffers && !empty($item['OFFERS_PROP']))
                {
                    ?>
                    <div id="<?=$itemIds['PROP_DIV']?>">
                        <?
                        foreach ($arParams['SKU_PROPS'] as $skuProperty)
                        {
                            $propertyId = $skuProperty['ID'];
                            $skuProperty['NAME'] = htmlspecialcharsbx($skuProperty['NAME']);
                            if (!isset($item['SKU_TREE_VALUES'][$propertyId]))
                                continue;
                            ?>
                            <div class="product-item-info-container product-item-hidden" data-entity="sku-block">
                                <div class="product-item-scu-container" data-entity="sku-line-block">
                                    <?=$skuProperty['NAME']?>
                                    <div class="product-item-scu-block">
                                        <div class="product-item-scu-list">
                                            <ul class="product-item-scu-item-list">
                                                <?
                                                foreach ($skuProperty['VALUES'] as $value)
                                                {
                                                    if (!isset($item['SKU_TREE_VALUES'][$propertyId][$value['ID']]))
                                                        continue;

                                                    $value['NAME'] = htmlspecialcharsbx($value['NAME']);

                                                    if ($skuProperty['SHOW_MODE'] === 'PICT')
                                                    {
                                                        ?>
                                                        <li class="product-item-scu-item-color-container" title="<?=$value['NAME']?>"
                                                            data-treevalue="<?=$propertyId?>_<?=$value['ID']?>" data-onevalue="<?=$value['ID']?>">
                                                            <div class="product-item-scu-item-color-block">
                                                                <div class="product-item-scu-item-color" title="<?=$value['NAME']?>"
                                                                     style="background-image: url('<?=$value['PICT']['SRC']?>');">
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <?
                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <li class="product-item-scu-item-text-container" title="<?=$value['NAME']?>"
                                                            data-treevalue="<?=$propertyId?>_<?=$value['ID']?>" data-onevalue="<?=$value['ID']?>">
                                                            <div class="product-item-scu-item-text-block">
                                                                <div class="product-item-scu-item-text"><?=$value['NAME']?></div>
                                                            </div>
                                                        </li>
                                                        <?
                                                    }
                                                }
                                                ?>
                                            </ul>
                                            <div style="clear: both;"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?
                        }
                        ?>
                    </div>
                    <?
                    foreach ($arParams['SKU_PROPS'] as $skuProperty)
                    {
                        if (!isset($item['OFFERS_PROP'][$skuProperty['CODE']]))
                            continue;

                        $skuProps[] = array(
                            'ID' => $skuProperty['ID'],
                            'SHOW_MODE' => $skuProperty['SHOW_MODE'],
                            'VALUES' => $skuProperty['VALUES'],
                            'VALUES_COUNT' => $skuProperty['VALUES_COUNT']
                        );
                    }

                    unset($skuProperty, $value);

                    if ($item['OFFERS_PROPS_DISPLAY'])
                    {
                        foreach ($item['JS_OFFERS'] as $keyOffer => $jsOffer)
                        {
                            $strProps = '';

                            if (!empty($jsOffer['DISPLAY_PROPERTIES']))
                            {
                                foreach ($jsOffer['DISPLAY_PROPERTIES'] as $displayProperty)
                                {
                                    $strProps .= '<dt>'.$displayProperty['NAME'].'</dt><dd>'
                                        .(is_array($displayProperty['VALUE'])
                                            ? implode(' / ', $displayProperty['VALUE'])
                                            : $displayProperty['VALUE'])
                                        .'</dd>';
                                }
                            }

                            $item['JS_OFFERS'][$keyOffer]['DISPLAY_PROPERTIES'] = $strProps;
                        }
                        unset($jsOffer, $strProps);
                    }
                }

                break;
        }
    }
}

if (
    $arParams['DISPLAY_COMPARE']
    && (!$haveOffers || $arParams['PRODUCT_DISPLAY_MODE'] === 'Y')
)
{
    ?>
    <div class="product-item-compare-container">
        <div class="product-item-compare">
            <div class="checkbox">
                <label id="<?=$itemIds['COMPARE_LINK']?>">
                    <input type="checkbox" data-entity="compare-checkbox">
                    <span data-entity="compare-title"><?=$arParams['MESS_BTN_COMPARE']?></span>
                </label>
            </div>
        </div>
    </div>
    <?
}
?>