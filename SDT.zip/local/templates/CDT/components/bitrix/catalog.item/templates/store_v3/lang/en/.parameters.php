<?php
$MESS["CP_BCI_TPL_USE_OFFER_NAME"] = "Use SKU names";
$MESS["USE_OFFER_NAME_TIP"] = "If checked, the current SKU name will be displayed instead of the product name. This feature requires extended item display mode.";
