<?php
$MESS["CT_BCI_TPL_MESS_CLOSE_BTN_TITLE"] = "Закрыть";