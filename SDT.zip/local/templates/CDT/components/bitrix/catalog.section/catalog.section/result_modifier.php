<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

/**
 * @var CBitrixComponentTemplate $this
 * @var CatalogSectionComponent $component
 */

$component = $this->getComponent();
$arParams = $component->applyTemplateModifications();
$cntProp = 0;

$property_enums = CIBlockPropertyEnum::GetList(Array("ID"=>"ASC", "SORT"=>"ASC"), Array("IBLOCK_ID"=>11));
while ($enum_fields = $property_enums->GetNext()) {
    if ($enum_fields["VALUE"]!="Да"){
        $cntProp++;
        $arResult['IB_PROPERTY'][]=array("ID" => $cntProp, "VALUE" => $enum_fields["VALUE"]);
    }
//    print_r($enum_fields);
}
foreach ($arResult['ITEMS'] as $item) {
    $MORE_PHOTO = array();
    if(isset($item['PROPERTIES']['MORE_PHOTO']['VALUE']) && is_array($item['PROPERTIES']['MORE_PHOTO']['VALUE']))
    {
        foreach($item['PROPERTIES']['MORE_PHOTO']['VALUE'] as $FILE)
        {
            $FILE = CFile::GetFileArray($FILE);
            if(is_array($FILE))
                $MORE_PHOTO[]=$FILE;
        }
    }

    $arResult['IB_ITEMS'][] = array(
        'NAME' => $item['NAME'],
        'PROPERTIES' => $item['PROPERTIES'],
        'MORE_PHOTO_2' => $MORE_PHOTO
    );
}?>
<!--<div class="index-product-img-slider">-->
<!--    --><?// // additional photos
////    print_r($arResult['IB_ITEMS']['MORE_PHOTO']);
//    $LINE_ELEMENT_COUNT = 2; // number of elements in a row
//    ?>
<!--    --><?// foreach ($arResult['IB_ITEMS']['PROPERTIES']['MORE_PHOTO_FILE'] as $PHOTO):?>
<!--        <a href="#" class="index-product_img">-->
<!--            <img border="0" src="--><?//= $PHOTO['SRC'] ?><!--" width="--><?//= $PHOTO['WIDTH'] ?><!--"-->
<!--                 height="--><?//= $PHOTO['HEIGHT'] ?><!--"-->
<!--                 alt="--><?//= $item['NAME'] ?><!--" title="--><?//= $item['NAME'] ?><!--"/>-->
<!--        </a>-->
<!--    --><?//endforeach ?>
<!--</div>-->
<?



//foreach ($arResult['IB_ITEMS'] as $arItem) {
//    var_dump($arResult["MORE_PHOTO"]);
//}
//var_dump($arResult['IB_PROPERTY']);
//print_r($Prop);