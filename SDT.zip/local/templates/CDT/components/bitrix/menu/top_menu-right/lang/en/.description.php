<?
$MESS ['MENU_TREE_NAME'] = "Tree-like menu";
$MESS ['MENU_TREE_DESC'] = "Tree-like menu";
?>