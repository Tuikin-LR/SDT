<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>

<? if (!empty($arResult)): ?>


    <ul class="header-menu-list">
        <? foreach ($arResult as $arItem): ?>

            <? if (!empty($arItem["SUBMENU"])) : ?>
                <li class="header-menu_item">
                    <a class="header-menu_link has--child" href="<?= $arItem["LINK"] ?>">
                        <?= $arItem["TEXT"] ?>
                        <svg class="arrow-down_icon">
                            <use href="assets/img/svg-icons.svg#arrow-down"></use>
                        </svg>
                    </a>
                    <div class="menu-child">
                        <ul class="menu-child-list">
                            <? foreach ($arItem["SUBMENU"] as $arItem2) : ?>
                                <li class="menu-child_item"><a
                                            href="<?= $arItem2["LINK"] ?>"><?= $arItem2["TEXT"] ?></a>
                                </li>
                            <? endforeach; ?>
                        </ul>
                    </div>
                </li>
            <? else : ?>
                <li class="header-menu_item"><a class="header-menu_link"
                                                href="<?= $arItem["LINK"] ?>"><?= $arItem["TEXT"] ?></a></li>
            <? endif; ?>
        <? endforeach; ?>
    </ul>
<? endif ?>


<!--<ul class="header-menu-list">-->
<!--    --><? // $arItem = reset($arResult);
//    foreach ($arResult as $arItem):
//    switch ($arItem["IS_PARENT"]):
//    case true:
//    if ($end_tags == 1) { ?>
<!--</ul></div></li>-->
<? // $end_tags = 0; ?>
<? // } ?>
<!--<li class="header-menu_item">-->
<!--<a class="header-menu_link has--child" href="--><? //= $arItem["LINK"] ?><!--">--><? //= $arItem["TEXT"] ?>
<!--    <svg class="arrow-down_icon">-->
<!--        <use href="--><? //=SITE_TEMPLATE_PATH?><!--/assets/img/svg-icons.svg#arrow-down"></use>-->
<!--    </svg>-->
<!--</a>-->
<!--<div class="menu-child">-->
<!--<ul  class="menu-child-list">-->
<? // $end_tags = 1 ?>
<? // break; ?>
<? // case false:
//switch ($arItem["DEPTH_LEVEL"]):
//case 1:
//?>
<? // if ($end_tags == 1) { ?>
<!--    </ul></div></li>-->
<!--    --><? // $end_tags = 0;
//} ?>
<!--    <li class="header-menu_item"><a href="--><? //= $arItem["LINK"] ?><!--">-->
<? //= $arItem["TEXT"] ?><!--</a></li>-->
<? // break; ?>
<? // case 2: ?>
<!--    <li class="menu-child_item"><a href="--><? //= $arItem["LINK"] ?><!--">-->
<? //= $arItem["TEXT"] ?><!--</a></li>-->
<!--    --><? // break; ?>
<? // default: ?>
<? // endswitch; ?>
<? // default: ?>
<? // endswitch; ?>
<? // endforeach ?>
<!--</ul>-->