<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>

<? if (!empty($arResult)): ?>

    <?
    sort($arResult);
    $showingItem = 0;
    foreach ($arResult as $arItem) {
        if ($arItem['IS_PARENT'] == false) {
            if ($showingItem == 0) {
                echo '<ul class="footer-menu-list">
        <li class="footer-menu_item"><a href="#">' . $arItem['TEXT'] . '</a></li>';
            } elseif ($showingItem == 3) {
                echo '<li class="footer-menu_item"><a href="#">' . $arItem['TEXT'] . '</a></li></ul>';
                $showingItem = -1;
            } else {
                echo '<li class="footer-menu_item"><a href="#">' . $arItem['TEXT'] . '</a></li>';
            }
            $showingItem++;
        }
    }
    ?>

<? endif ?>


