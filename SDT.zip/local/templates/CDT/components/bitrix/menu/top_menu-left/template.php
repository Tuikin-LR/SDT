<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?if (!empty($arResult)):?>
<div class="footer-social">
	<ul class="footer-social-list">
	<?switch ($arItem["ITEM_INDEX"]):
		case 0:?>
			<li>
                <a class="footer-social_link" href="#" target="_blank">
                    <svg class="social_icon icon--facebook">
                        <use href="<?echo SITE_TEMPLATE_PATH;?>/assets/img/svg-icons.svg#facebook"></use>
					</svg>
                </a>
            </li>
		
		<?case 1:?>
            <li>
                <a class="footer-social_link" href="#" target="_blank">
                    <svg class="social_icon icon--twitter">
                        <use href="<?echo SITE_TEMPLATE_PATH;?>/assets/img/svg-icons.svg#twitter"></use>
                    </svg>
                </a>
            </li>		
		
		<?case 2:?>
		    <li>
                <a class="footer-social_link" href="#" target="_blank">
                    <svg class="social_icon icon--youtube">
                        <use href="<?echo SITE_TEMPLATE_PATH;?>/assets/img/svg-icons.svg#youtube"></use>
                    </svg>
                </a>
            </li>	
		
		<?case 3:?>
		    <li>
                <a class="footer-social_link" href="#" target="_blank">
                    <svg class="social_icon icon--insta">
                        <use href="<?echo SITE_TEMPLATE_PATH;?>/assets/img/svg-icons.svg#instagram"></use>
                    </svg>
                </a>
            </li>	
		
		<?case 4:?>
		    <li>
                <a class="footer-social_link" href="#" target="_blank">
                    <svg class="social_icon icon--telegram">
                        <use href="<?echo SITE_TEMPLATE_PATH;?>/assets/img/svg-icons.svg#telegram"></use>
                    </svg>
                </a>
            </li>	
		
		<?default:?>
	<?endswitch;?>
	</ul>
</div>

<?endif?>