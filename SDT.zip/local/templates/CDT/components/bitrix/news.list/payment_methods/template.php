<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>
<ul class="footer-pay-list">
    <? foreach ($arResult['_ITEMS'] as $arItem){ ?>
    <li class="footer-pay_item">
        <img src="<?= $arItem ?>" alt="">
    </li>
    <?}?>
</ul>






  
