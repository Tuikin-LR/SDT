<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

$res = CIBlockElement::GetProperty(13, 345);
while ($row = $res->Fetch())
	{$path_logo = $row['VALUE'];}
?>
<div class="index-catalog-list">
	<div class="index-catalog-item catalog-img">
        <a href="#"><img src="<?echo $path_logo?>" alt=""></a>
    </div>

<?foreach($arResult["ITEMS"] as $arItem):?>
	<?
	
	//var_dump($arItem);
	
	
	$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
	$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
	?>
	<div class="index-catalog-item" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
		<?if($arParams["DISPLAY_NAME"]!="N" && $arItem["NAME"]):?>
				<?if ($arItem["NAME"] == "%Распродажа") :?>
					<a href="<?echo $arItem["LINK"]?>" class="catalog-menu__link is-red"><?echo $arItem["NAME"]?></a>
					<?else:?>
					<?if ($arItem["IBLOCK_SECTION_ID"]!=NULL) :?>
					<a href="<?echo $arItem["LINK"]?>" class="catalog-menu__link"><?echo $arItem["NAME"]?>f</a>
						<?$res = CIBlockSection::GetByID($arItem["IBLOCK_SECTION_ID"]);
					if($ar_res = $res->GetNext())
					var_dump ($ar_res['NAME']);?>
					<?else:?>
					<a href="<?echo $arItem["LINK"]?>" class="catalog-menu__link"><?echo $arItem["NAME"]?>fff</a>
					<?endif;?>
			<?endif;?>		
		<?endif;?>		
	</div>
	

	
<?endforeach;?>
</div>
