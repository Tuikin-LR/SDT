<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
//var_dump($arParams['PAGER_BASE_LINK_ENABLE']);
if ($arParams['PLACE'] == 'HEADER'){
    ?>
    <svg class="header-phone_icon">
        <use href="<?echo $arResult['PATH_IMG_PHONE'];?>"></use>
    </svg>
<?}

if ($arParams['PLACE'] == 'FOOTER'){
    ?>
    <svg class="footer-phone_icon">
        <use href="<?echo $arResult['PATH_IMG_PHONE'];?>"></use>
    </svg>
<?}

print_r($arResult['NUMBER']);
?>




  
