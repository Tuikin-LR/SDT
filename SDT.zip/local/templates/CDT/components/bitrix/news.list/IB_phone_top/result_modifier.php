<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();



foreach ($arResult['ITEMS'] as $arItem) {
    if ($arItem['NAME'] == 'Общие настройки') {
        $res = CIBlockElement::GetProperty($arItem['IBLOCK_ID'], $arItem['ID']);
        while ($row = $res->Fetch()) {
            if ($row['CODE'] == 'NUMBER') {
                $arResult['NUMBER'] = $row['VALUE'];
            }
            if ($row['CODE'] == 'PATH_IMG_PHONE') {
                $arResult['PATH_IMG_PHONE'] = $row['VALUE'];
            }
        }
    }
}
?>