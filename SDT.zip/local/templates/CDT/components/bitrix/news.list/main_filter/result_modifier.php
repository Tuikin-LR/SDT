<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arItem = array_shift($arResult["ITEMS"]);

$res = CIBlockElement::GetProperty($arItem['IBLOCK_ID'], $arItem['ID']);
while ($row = $res->Fetch())
{
    if ($row['CODE']=='number'){$arResult['NUM_PHONE'] = $row['VALUE'];}
    if ($row['CODE']=='path_img'){$arResult['PATH_IMG'] = $row['VALUE'];}
}

?>