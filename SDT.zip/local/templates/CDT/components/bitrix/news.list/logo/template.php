<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<?
if ($arParams["PLACE"] == "HEADER") {
?>
	<a class="header-logo logo--big" href="/"><img src="<?echo $arResult['PATH_LOGO'];?>" alt=""></a>
	<a class="header-logo logo--small" href="/"><img src="<?echo $arResult['PATH_LOGO_SMALL'];?>" alt=""></a>
<?
}
if ($arParams["PLACE"] == "FOOTER"){
?>
    <a href="/" class="footer-logo"><img src="<?echo $arResult['PATH_LOGO_FOOTER'];?>" alt=""></a>
<?
}
?>