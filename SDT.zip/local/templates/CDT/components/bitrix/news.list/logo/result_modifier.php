<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

foreach ($arResult['ITEMS'] as $arItem) {
    if ($arItem['NAME'] == 'Общие настройки') {
        $res = CIBlockElement::GetProperty($arItem['IBLOCK_ID'], $arItem['ID']);
        while ($row = $res->Fetch()) {
            if ($row['CODE'] == 'PATH_LOGO') {
                $arResult['PATH_LOGO'] = $row['VALUE'];
            }

            if ($row['CODE'] == 'PATH_LOGO_SMALL') {
                $arResult['PATH_LOGO_SMALL'] = $row['VALUE'];
            }

            if ($row['CODE'] == 'PATH_LOGO_FOOTER') {
                $arResult['PATH_LOGO_FOOTER'] = $row['VALUE'];
            }
        }
    }
}
?>