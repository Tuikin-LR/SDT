<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

$strSectionEdit = CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "SECTION_EDIT");
$strSectionDelete = CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "SECTION_DELETE");
$arSectionDeleteParams = array("CONFIRM" => GetMessage('CT_BCSL_ELEMENT_DELETE_CONFIRM'));

$this->AddEditAction($arResult['SECTION']['ID'], $arResult['SECTION']['EDIT_LINK'], $strSectionEdit);
$this->AddDeleteAction($arResult['SECTION']['ID'], $arResult['SECTION']['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);

        foreach ($arResult['_SECTIONS'] as &$arSection) {

            $this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], $strSectionEdit);
            $this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);

            $isRed = false;

            if ($arSection["NAME"] == "%Распродажа")
                $isRed = true;
            ?>
            <div class="index-catalog-item"><a class="catalog-menu__link <? if ($isRed): ?> is-red<? $isRed = false; endif; ?>"
                                               href="#"><? echo $arSection["NAME"]; ?></a>
                <?
                if ($arSection["SUBMENU"]) {
                    ?>
                    <div class="index-catalog-submenu">
                        <div class="catalog-submenu__inner">

                            <? foreach ($arSection["SUBMENU"] as $arSection2) {
                                ?>
                                <div class="catalog-submenu-list">
                                    <div class="catalog-submenu__subtitle">
                                        <a href="#"><? echo $arSection2["NAME"]; ?></a>
                                    </div>
                                    <div class="catalog-submenu__list">

                                        <? foreach ($arSection2["SUBMENU"] as $arSection3) { ?>
                                            <div class="catalog-submenu__item">
                                                <a href="#"><? echo $arSection3["NAME"]; ?></a>
                                            </div>
                                            <?
                                        } ?>
                                    </div>
                                </div>
                                <?
                            } ?>
                        </div>
                    </div>
                    <?
                } ?>
            </div>
            <?
        }
        unset($arSection);

?>
<?
?>