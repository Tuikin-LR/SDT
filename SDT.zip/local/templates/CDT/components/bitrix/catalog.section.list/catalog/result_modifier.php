<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();


$arr2 = array();

$cntSections = array_key_last($arResult['SECTIONS']);
$arResult['__SECTIONS'] = $arResult['SECTIONS'];
$arResult['_SECTIONS'] = catalogItem($arResult['__SECTIONS'], $cntSections, 0, $arr2);

//echo '<pre>';
//var_dump($arResult['_SECTIONS']);
//echo '</pre>';
?>