<?
$MESS ['subscr_form_title_desc'] = "Выберите рассылку";
$MESS ['subscr_form_email_title'] = "Введите ваш e-mail";
$MESS ['subscr_form_button'] = "Подписаться";
$MESS ['subscr_form_response_ERROR'] = "Что-то пошло не так";
$MESS ['subscr_form_response_NOTE'] = "Поздравляем!";
$MESS ['subscr_form_button_sent'] = "ГОТОВО";
?>