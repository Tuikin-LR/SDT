<?
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
$APPLICATION->SetTitle("test");
?>
<?
//echo microtime();
//echo '<br />';
//$i = 0;
//$ar = array(1,2,1,54,56,56,23,234,43,1);
//while ($i < 1000) {
//    $n = array_key_last($ar);
//    $i++;
//}
//echo microtime();
//echo '<br />';
//$i = 0;
//$ar = array(1,2,1,54,56,56,23,234,43,1);
//while ($i < 1000) {
//    $n = count($ar)-1;
//    $i++;
//}
//echo microtime();

if ($isTest){
	echo "<pre>";
	echo "Test";
	echo "</pre>";
}

echo '<pre>';
if (($_SERVER["DOCUMENT_ROOT"] . $_SERVER["PHP_SELF"]) == $test_siteMarker) {
    echo ' OK';
}
echo '</pre>';
?>

<? $APPLICATION->IncludeComponent(
	"bitrix:catalog.section.list",
	"catalog",
	array(
		"ADD_SECTIONS_CHAIN" => "N",
		"CACHE_FILTER" => "N",
		"CACHE_GROUPS" => "Y",
		"CACHE_TIME" => "36000000",
		"CACHE_TYPE" => "N",
		"COUNT_ELEMENTS" => "Y",
		"COUNT_ELEMENTS_FILTER" => "CNT_ACTIVE",
		"FILTER_NAME" => "sectionsFilter",
		"IBLOCK_ID" => "11",
		"IBLOCK_TYPE" => "catalog",
		"SECTION_CODE" => "",
		"SECTION_FIELDS" => array(
			0 => "NAME",
			1 => "",
		),
		"SECTION_ID" => $_REQUEST["SECTION_ID"],
		"SECTION_URL" => "",
		"SECTION_USER_FIELDS" => array(
			0 => "",
			1 => "",
		),
		"SHOW_PARENT_NAME" => "Y",
		"TOP_DEPTH" => "3",
		"VIEW_MODE" => "LIST",
		"COMPONENT_TEMPLATE" => "catalog",
		"SHOW_ANGLE" => "Y",
		"OFFSET_MODE" => "N"
	),
	false
); ?>

<?
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php");
?>