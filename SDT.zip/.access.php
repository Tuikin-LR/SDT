<?
$PERM["personal"]["8"]="W";
$PERM["catalog"]["8"]="W";
$PERM["news"]["8"]="W";
$PERM["about"]["8"]="W";
$PERM["index.php"]["8"]="W";
$PERM["/"]["*"]="R";
?>