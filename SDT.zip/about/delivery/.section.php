<?
$sSectionName = "Доставка";
$arDirProperties = array(
);
?>