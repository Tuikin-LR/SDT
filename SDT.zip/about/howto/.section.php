<?
$sSectionName = "Как купить";
$arDirProperties = array(
);
?>