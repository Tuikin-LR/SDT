<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?/*if(IsModuleInstalled("idea")):?>
    <?$APPLICATION->IncludeComponent("bitrix:idea.popup", "", array(
            "BLOG_URL" => "#IDEA_BLOG_CODE#",
            "IBLOCK_CATOGORIES" => "#IDEA_IBLOCK_CATEGORY#",
            "PATH_IDEA_INDEX" => "/about/idea/",
            "PATH_IDEA_POST" => "/about/idea/#post_id#/",
            "BUTTON_COLOR" => "",
            "POST_BIND_STATUS_DEFAULT" => "#IDEA_BIND_STATUS_DEFAULT#",
            "FORGOT_PASSWORD_URL" => "/login/?forgot_password=yes",
            "REGISTER_URL" => "/login/?clear_cache=Y",
            "CATOGORIES_CNT" => "4",
            "LIST_MESSAGE_COUNT" => "8",
            "CACHE_TYPE" => "A",
            "CACHE_TIME" => "3600",
            "SHOW_RATING" => "Y",
            "RATING_TEMPLATE" => "like",
            "DISABLE_SONET_LOG" => "Y",
            "DISABLE_EMAIL" => "N"
            ),
            false
    );
    ?>
<?endif;*/?>