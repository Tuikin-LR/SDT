<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
$APPLICATION->IncludeComponent("bitrix:eshop.facebook.plugin", "",
	array(
		"ESHOP_FACEBOOK_LINK"=>"http://www.facebook.com/1CBitrix"
	),
	false
);
?>